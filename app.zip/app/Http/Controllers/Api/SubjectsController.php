<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Validator;

class SubjectsController extends Controller
{
    /**
     * Return a list of subjects filtered by grade_id and optional stream_id.
     * Caches static listings for high performance.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'grade_id' => ['nullable', 'integer', 'exists:grades,id'],
            'stream_id' => ['nullable', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $gradeId = $request->filled('grade_id') ? (int) $request->query('grade_id') : null;
        $streamId = $request->query('stream_id');

        $cacheKey = 'api_subjects_g' . ($gradeId ?? 'all') . '_s' . ($streamId ?? 'all');

        $subjects = Cache::remember($cacheKey, 3600, function () use ($gradeId, $streamId) {
            $query = Subject::with('chapters');

            if ($gradeId !== null) {
                $query->where('grade_id', $gradeId);
            }

            if ($streamId !== null && $streamId !== '') {
                $streamIdInt = (int) $streamId;
                $query->where(function ($q) use ($streamIdInt) {
                    $q->where('stream_id', $streamIdInt)
                      ->orWhereNull('stream_id');
                });
            }

            return $query->get();
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Subjects retrieved successfully',
            'data' => $subjects,
        ]);
    }

    /**
     * Search subjects by query term with optional grade_id and stream_id filtering.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function search(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'q' => ['nullable', 'string', 'max:255'],
            'grade_id' => ['nullable', 'integer', 'exists:grades,id'],
            'stream_id' => ['nullable', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $query = Subject::with('chapters');

        if ($request->filled('q')) {
            $searchTerm = strtolower(trim($request->query('q')));
            $query->whereRaw('LOWER(title) LIKE ?', ['%' . $searchTerm . '%']);
        }

        if ($request->filled('grade_id')) {
            $query->where('grade_id', (int) $request->query('grade_id'));
        }

        if ($request->filled('stream_id')) {
            $streamIdInt = (int) $request->query('stream_id');
            $query->where(function ($q) use ($streamIdInt) {
                $q->where('stream_id', $streamIdInt)
                  ->orWhereNull('stream_id');
            });
        }

        $subjects = $query->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Subjects retrieved successfully',
            'data' => $subjects,
        ]);
    }

    /**
     * Get top 3 recently viewed subjects (from session or padded to 3 active subjects).
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getRecentlyViewed(Request $request): JsonResponse
    {
        $recentIds = session()->get('recently_viewed_subjects', []);
        $subjects = collect();

        if (!empty($recentIds) && is_array($recentIds)) {
            $fetched = Subject::with('chapters')->whereIn('id', $recentIds)->get();
            $subjects = $fetched->sortBy(function ($subject) use ($recentIds) {
                return array_search($subject->id, $recentIds);
            })->take(3)->values();
        }

        if ($subjects->count() < 3) {
            $existingIds = $subjects->pluck('id')->all();
            $fallback = Subject::with('chapters')
                ->whereNotIn('id', $existingIds)
                ->take(3 - $subjects->count())
                ->get();
            $subjects = $subjects->concat($fallback)->take(3)->values();
        }

        return response()->json([
            'status' => 'success',
            'data' => $subjects,
        ]);
    }

    /**
     * Record a subject as recently viewed in session.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function recordRecentlyViewed(Request $request): JsonResponse
    {
        $recent = session()->get('recently_viewed_subjects', []);
        if (!is_array($recent)) {
            $recent = [];
        }

        $subjectId = $request->input('subject_id') ?? $request->input('id');

        if ($subjectId) {
            $recent = array_values(array_unique(array_merge([(int) $subjectId], $recent)));
            session()->put('recently_viewed_subjects', array_slice($recent, 0, 10));
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Recorded successfully',
        ]);
    }
}

