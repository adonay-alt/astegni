<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Chapter;
use App\Models\Grade;
use App\Models\Note;
use App\Models\Quiz;
use App\Models\Resource;
use App\Models\Subject;
use App\Models\Textbook;
use App\Models\Video;
use App\Jobs\GenerateChapterNotesJob;
use App\Jobs\GenerateChapterQuizJob;
use App\Services\GeminiService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class ChapterController extends Controller
{
    /**
     * Display a listing of chapters with optional filtering by grade_id and/or subject_id.
     * Caches query results for high performance.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        $gradeId = $request->query('grade_id');
        $subjectId = $request->query('subject_id');

        $cacheKey = 'api_chapters_g' . ($gradeId ?? 'all') . '_s' . ($subjectId ?? 'all');

        $chapters = Cache::remember($cacheKey, 3600, function () use ($gradeId, $subjectId) {
            $query = Chapter::with(['grade', 'subject']);

            if ($gradeId !== null) {
                $query->where('grade_id', $gradeId);
            }

            if ($subjectId !== null) {
                $query->where('subject_id', $subjectId);
            }

            return $query->get();
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Chapters retrieved successfully',
            'data' => $chapters,
        ]);
    }

    /**
     * Display a listing of chapters for a specific grade.
     *
     * @param int|string $gradeId
     * @return JsonResponse
     */
    public function getByGrade($gradeId): JsonResponse
    {
        $chapters = Cache::remember('api_chapters_grade_' . $gradeId, 3600, function () use ($gradeId) {
            return Chapter::where('grade_id', $gradeId)
                ->with(['grade', 'subject'])
                ->get();
        });

        return response()->json([
            'status' => 'success',
            'message' => 'Chapters retrieved successfully',
            'data' => $chapters,
        ]);
    }

    /**
     * Display the specified chapter with grade and subject information.
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function show($id): JsonResponse
    {
        $chapter = Chapter::with(['grade', 'subject'])->find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Chapter retrieved successfully',
            'data' => $chapter,
        ]);
    }


/**
 * Display a listing of chapters for a specific subject.
 *
 * @param int|string $subjectId
 * @return JsonResponse
 */
public function getBySubject($subjectId): JsonResponse
{
    $chapters = Cache::remember('api_chapters_subject_' . $subjectId, 3600, function () use ($subjectId) {
        return Chapter::where('subject_id', $subjectId)
            ->with(['grade', 'subject'])
            ->get();
    });

    return response()->json([
        'status' => 'success',
        'message' => 'Chapters retrieved successfully',
        'data' => $chapters,
    ]);
}
    /**
     * Display all learning content belonging to a specific chapter.
     * Safely triggers on-demand AI note generation with cache stampede protection.
     *
     * @param int|string $chapterId
     * @return JsonResponse
     */
    public function getContent($chapterId): JsonResponse
    {
        $chapter = Chapter::with(['grade', 'subject', 'textbooks'])->find($chapterId);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        $videos = Video::where('chapter_id', $chapterId)->get();
        $notes = Note::where('chapter_id', $chapterId)->get();
        $textbooks = Textbook::where('chapter_id', $chapterId)->get();
        $resources = Resource::where('chapter_id', $chapterId)->get();
        $quizzes = Quiz::where('chapter_id', $chapterId)->with('questions')->get();

        $hasNotes = !empty(trim((string) $chapter->ai_generated_notes));

        $chapterData = [
            'id' => $chapter->id,
            'name' => $chapter->title,
            'title' => $chapter->title,
            'chapter_number' => $chapter->chapter_number,
            'description' => $chapter->description,
            'pdf_path' => $chapter->pdf_path,
            'ai_generated_notes' => $chapter->ai_generated_notes,
            'ai_generated_notes_html' => $chapter->ai_generated_notes ? Str::markdown($chapter->ai_generated_notes) : null,
            'notes_generated_at' => $chapter->notes_generated_at,
            'grade_id' => $chapter->grade_id,
            'subject_id' => $chapter->subject_id,
            'grade' => $chapter->grade,
            'subject' => $chapter->subject,
        ];

        // Case A: Notes already exist
        if ($hasNotes) {
            return response()->json([
                'status' => 'success',
                'message' => 'Chapter content retrieved successfully',
                'data' => [
                    'chapter' => array_merge($chapterData, ['notes_status' => 'ready']),
                    'notes_status' => 'ready',
                    'videos' => $videos,
                    'notes' => $notes,
                    'textbooks' => $textbooks,
                    'resources' => $resources,
                    'quizzes' => $quizzes,
                ],
            ], 200);
        }

        // Case B: Check for recent failure lock
        $failedNotesKey = "notes_failed_chapter_{$chapter->id}";
        if (Cache::has($failedNotesKey)) {
            return response()->json([
                'status' => 'success',
                'message' => 'Note generation previously failed for this chapter. Please contact support or notify admin.',
                'data' => [
                    'chapter' => array_merge($chapterData, ['notes_status' => 'not_available']),
                    'notes_status' => 'not_available',
                    'videos' => $videos,
                    'notes' => $notes,
                    'textbooks' => $textbooks,
                    'resources' => $resources,
                    'quizzes' => $quizzes,
                ],
            ], 200);
        }

        // Case C: Check physical PDF existence on server disk
        $pdfPath = $chapter->resolvePdfPath();
        if (!$pdfPath) {
            return response()->json([
                'status' => 'success',
                'message' => 'No physical textbook PDF found on server for this chapter.',
                'data' => [
                    'chapter' => array_merge($chapterData, ['notes_status' => 'not_available']),
                    'notes_status' => 'not_available',
                    'videos' => $videos,
                    'notes' => $notes,
                    'textbooks' => $textbooks,
                    'resources' => $resources,
                    'quizzes' => $quizzes,
                ],
            ], 200);
        }

        // Case D: Notes missing, physical PDF available - Stampede lock check
        $lockKey = "generating_notes_chapter_{$chapter->id}";

        if (Cache::has($lockKey)) {
            // Another student already triggered it; return waiting status
            return response()->json([
                'status' => 'success',
                'message' => 'AI is currently preparing notes for this chapter.',
                'data' => [
                    'chapter' => array_merge($chapterData, ['notes_status' => 'generating']),
                    'notes_status' => 'generating',
                    'retry_after_seconds' => 10,
                    'videos' => $videos,
                    'notes' => $notes,
                    'textbooks' => $textbooks,
                    'resources' => $resources,
                    'quizzes' => $quizzes,
                ],
            ], 200);
        }

        // Acquire 3-minute lock to prevent stampedes and dispatch background worker
        Cache::put($lockKey, true, now()->addMinutes(3));
        GenerateChapterNotesJob::dispatch($chapter);

        return response()->json([
            'status' => 'success',
            'message' => 'AI note generation started for this chapter. Check back shortly.',
            'data' => [
                'chapter' => array_merge($chapterData, ['notes_status' => 'generating']),
                'notes_status' => 'generating',
                'retry_after_seconds' => 15,
                'videos' => $videos,
                'notes' => $notes,
                'textbooks' => $textbooks,
                'resources' => $resources,
                'quizzes' => $quizzes,
            ],
        ], 200);
    }
    
    public function getFeatured(): \Illuminate\Http\JsonResponse
    {
        $chapters = \App\Models\Chapter::where('is_featured', true)->get();
        
        return response()->json([
            'status' => 'success',
            'data' => $chapters
        ], 200);
    }

    /**
     * Dispatch Google Gemini background job to generate chapter notes from textbook PDF.
     *
     * @param Request $request
     * @param int|string $id
     * @return JsonResponse
     */
    public function generateNotes(Request $request, $id): JsonResponse
    {
        $chapter = Chapter::with(['grade', 'subject', 'textbooks'])->find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        // Check if PDF exists on chapter or textbook relationship
        $hasTextbook = $chapter->pdf_path || $chapter->textbooks()->count() > 0;
        if (!$hasTextbook) {
            return response()->json([
                'status' => 'error',
                'message' => 'No PDF file attached to this chapter or its associated textbooks.',
            ], 422);
        }

        // Return existing notes if already generated and force/overwrite is not requested
        if (!empty($chapter->ai_generated_notes) && !$request->boolean('force') && !$request->boolean('overwrite')) {
            return response()->json([
                'status' => 'success',
                'message' => 'Notes already exist for this chapter. Pass force=true or overwrite=true to regenerate.',
                'data' => [
                    'chapter_id' => $chapter->id,
                    'title' => $chapter->title,
                    'ai_generated_notes' => $chapter->ai_generated_notes,
                    'ai_generated_notes_html' => Str::markdown($chapter->ai_generated_notes),
                    'notes_generated_at' => $chapter->notes_generated_at,
                    'already_exists' => true,
                ]
            ]);
        }

        // Clear any previous failure lock for this chapter
        Cache::forget("notes_failed_chapter_{$chapter->id}");

        // If request asks for sync execution (e.g. testing)
        if ($request->boolean('sync')) {
            try {
                $job = new GenerateChapterNotesJob($chapter);
                $job->handle(app(\App\Services\GeminiService::class));
                $chapter->refresh();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Notes generated synchronously.',
                    'data' => [
                        'chapter_id' => $chapter->id,
                        'title' => $chapter->title,
                        'ai_generated_notes' => $chapter->ai_generated_notes,
                        'ai_generated_notes_html' => Str::markdown($chapter->ai_generated_notes ?? ''),
                        'notes_generated_at' => $chapter->notes_generated_at,
                    ]
                ]);
            } catch (\Exception $e) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed generating notes: ' . $e->getMessage(),
                ], 500);
            }
        }

        // Dispatch background job
        GenerateChapterNotesJob::dispatch($chapter);

        return response()->json([
            'status' => 'success',
            'message' => 'Gemini AI is generating study notes in the background.',
            'data' => [
                'chapter_id' => $chapter->id,
                'title' => $chapter->title,
                'status' => 'processing',
            ]
        ]);
    }

    /**
     * Dispatch Google Gemini background job to generate chapter quiz questions from AI notes.
     *
     * @param Request $request
     * @param int|string $id
     * @return JsonResponse
     */
    public function generateQuiz(Request $request, $id): JsonResponse
    {
        $chapter = Chapter::with(['grade', 'subject'])->find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        // Verify chapter has AI generated notes
        if (empty($chapter->ai_generated_notes)) {
            return response()->json([
                'status' => 'error',
                'message' => 'No AI-generated notes found for this chapter. Please generate chapter notes first before creating a quiz.',
            ], 422);
        }

        // Check if quiz already exists and force/overwrite/regenerate is not requested
        $existingQuiz = Quiz::where('chapter_id', $chapter->id)->first();
        $shouldRegenerate = $request->boolean('force') || $request->boolean('overwrite') || $request->boolean('regenerate');

        if ($existingQuiz && !$shouldRegenerate) {
            return response()->json([
                'status' => 'success',
                'message' => 'Quiz already exists for this chapter. Pass force=true, overwrite=true, or regenerate=true to replace with a new AI quiz.',
                'data' => [
                    'chapter_id' => $chapter->id,
                    'quiz_id' => $existingQuiz->id,
                    'title' => $existingQuiz->title,
                    'already_exists' => true,
                ]
            ]);
        }

        // Clear any previous failure lock for this chapter
        Cache::forget("quiz_failed_chapter_{$chapter->id}");

        // Sync execution support (e.g. for testing)
        if ($request->boolean('sync')) {
            try {
                $job = new GenerateChapterQuizJob($chapter);
                $job->handle(app(\App\Services\GeminiService::class));

                $quiz = Quiz::where('chapter_id', $chapter->id)->with('questions')->first();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Quiz generated synchronously.',
                    'data' => $quiz,
                ]);
            } catch (\Exception $e) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed generating quiz: ' . $e->getMessage(),
                ], 500);
            }
        }

        // Dispatch background job
        GenerateChapterQuizJob::dispatch($chapter);

        return response()->json([
            'status' => 'success',
            'message' => 'Gemini AI is generating quiz questions in the background.',
            'data' => [
                'chapter_id' => $chapter->id,
                'title' => $chapter->title,
                'status' => 'processing',
            ]
        ]);
    }

    /**
     * Get the quiz and its questions for a specific chapter.
     * Safely triggers on-demand AI quiz generation with cache stampede protection and smart source fallback.
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function getQuiz($id): JsonResponse
    {
        $chapter = Chapter::with(['textbooks'])->find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        // 1. Check if quiz already exists in database
        $quiz = Quiz::where('chapter_id', $id)->with('questions')->first();

        if ($quiz) {
            $quizArray = $quiz->toArray();
            return response()->json([
                'status' => 'success',
                'message' => 'Chapter quiz retrieved successfully',
                'data' => array_merge($quizArray, [
                    'chapter_id' => $chapter->id,
                    'quiz_status' => 'ready',
                    'quiz' => $quizArray,
                ]),
            ], 200);
        }

        // 2. Check for recent failure lock
        $failedQuizKey = "quiz_failed_chapter_{$chapter->id}";
        if (Cache::has($failedQuizKey)) {
            return response()->json([
                'status' => 'success',
                'message' => 'Quiz generation previously failed for this chapter. Please contact support or notify admin.',
                'data' => [
                    'chapter_id' => $chapter->id,
                    'quiz_status' => 'not_available',
                ]
            ], 200);
        }

        // 3. Check if source exists (AI notes or physical textbook PDF)
        $hasSource = !empty(trim((string) $chapter->ai_generated_notes)) || (bool) $chapter->resolvePdfPath();

        if (!$hasSource) {
            return response()->json([
                'status' => 'success',
                'message' => 'No notes or textbook PDF available to generate a quiz.',
                'data' => [
                    'chapter_id' => $chapter->id,
                    'quiz_status' => 'not_available',
                ]
            ], 200);
        }

        // 4. Stampede lock check
        $lockKey = "generating_quiz_chapter_{$chapter->id}";
        if (Cache::has($lockKey)) {
            return response()->json([
                'status' => 'success',
                'message' => 'Quiz is currently being generated by AI.',
                'data' => [
                    'chapter_id' => $chapter->id,
                    'quiz_status' => 'generating',
                    'retry_after_seconds' => 10,
                ]
            ], 200);
        }

        // 5. Acquire lock & dispatch job
        Cache::put($lockKey, true, now()->addMinutes(3));
        GenerateChapterQuizJob::dispatch($chapter);

        return response()->json([
            'status' => 'success',
            'message' => 'AI quiz generation started. Check back shortly.',
            'data' => [
                'chapter_id' => $chapter->id,
                'quiz_status' => 'generating',
                'retry_after_seconds' => !empty($chapter->ai_generated_notes) ? 8 : 15,
            ]
        ], 200);
    }

    /**
     * Get chapter content (notes) using natural parameters: grade, subject, chapter number.
     *
     * @param string|int $grade
     * @param string|int $subject
     * @param int|string $chapterNumber
     * @return JsonResponse
     */
    public function getContentByLookup($grade, $subject, $chapterNumber): JsonResponse
    {
        $resolved = $this->resolveChapterByNaturalKeys($grade, $subject, $chapterNumber);

        if ($resolved instanceof JsonResponse) {
            return $resolved;
        }

        return $this->getContent($resolved->id);
    }

    /**
     * Get chapter quiz using natural parameters: grade, subject, chapter number.
     *
     * @param string|int $grade
     * @param string|int $subject
     * @param int|string $chapterNumber
     * @return JsonResponse
     */
    public function getQuizByLookup($grade, $subject, $chapterNumber): JsonResponse
    {
        $resolved = $this->resolveChapterByNaturalKeys($grade, $subject, $chapterNumber);

        if ($resolved instanceof JsonResponse) {
            return $resolved;
        }

        return $this->getQuiz($resolved->id);
    }

    /**
     * Ask a question or chat with the AI tutor for a specific chapter.
     *
     * @param Request $request
     * @param int|string $id
     * @param GeminiService $gemini
     * @return JsonResponse
     */
    public function chat(Request $request, $id, GeminiService $gemini): JsonResponse
    {
        $request->validate([
            'message' => 'required|string|max:600',
            'history' => 'nullable|array|max:10',
        ]);

        $chapter = Chapter::with(['grade', 'subject'])->find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        try {
            $reply = $gemini->chatWithChapter(
                $chapter,
                $request->input('message'),
                $request->input('history', [])
            );

            return response()->json([
                'status' => 'success',
                'data' => [
                    'reply' => $reply,
                    'chapter_id' => $chapter->id,
                ]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'AI Tutor is currently unavailable: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Chat with AI tutor using natural parameters: grade, subject, chapter number.
     *
     * @param Request $request
     * @param string|int $grade
     * @param string|int $subject
     * @param int|string $chapterNumber
     * @param GeminiService $gemini
     * @return JsonResponse
     */
    public function chatByLookup(Request $request, $grade, $subject, $chapterNumber, GeminiService $gemini): JsonResponse
    {
        $resolved = $this->resolveChapterByNaturalKeys($grade, $subject, $chapterNumber);

        if ($resolved instanceof JsonResponse) {
            return $resolved;
        }

        return $this->chat($request, $resolved->id, $gemini);
    }

    /**
     * Helper method to resolve a Chapter model instance by natural keys (grade, subject, chapter_number).
     *
     * @param string|int $gradeParam
     * @param string|int $subjectParam
     * @param int|string $chapterNumber
     * @return Chapter|JsonResponse
     */
    protected function resolveChapterByNaturalKeys($gradeParam, $subjectParam, $chapterNumber): Chapter|JsonResponse
    {
        // 1. Resolve Grade
        $grade = null;
        if (is_numeric($gradeParam)) {
            $grade = Grade::select(['id', 'name'])
                ->where('id', $gradeParam)
                ->orWhere('name', 'like', "%{$gradeParam}%")
                ->first();
        } else {
            $cleanGrade = str_replace('-', ' ', (string) $gradeParam);
            $grade = Grade::select(['id', 'name'])
                ->where('name', $gradeParam)
                ->orWhere('name', 'like', "%{$gradeParam}%")
                ->orWhere('name', 'like', "%{$cleanGrade}%")
                ->first();
        }

        if (!$grade) {
            return response()->json([
                'status' => 'error',
                'message' => "Grade not found for: {$gradeParam}",
            ], 404);
        }

        // 2. Resolve Subject
        $cleanSubject = str_replace('-', ' ', (string) $subjectParam);
        $subject = Subject::select(['id', 'grade_id', 'title'])
            ->where('grade_id', $grade->id)
            ->where(function ($q) use ($subjectParam, $cleanSubject) {
                if (is_numeric($subjectParam)) {
                    $q->where('id', $subjectParam);
                }
                $q->orWhere('title', 'like', $subjectParam)
                  ->orWhere('title', 'like', "%{$subjectParam}%")
                  ->orWhere('title', 'like', "%{$cleanSubject}%");
            })
            ->first();

        if (!$subject) {
            $subject = Subject::select(['id', 'grade_id', 'title'])
                ->where(function ($q) use ($subjectParam, $cleanSubject) {
                    if (is_numeric($subjectParam)) {
                        $q->where('id', $subjectParam);
                    }
                    $q->orWhere('title', 'like', $subjectParam)
                      ->orWhere('title', 'like', "%{$subjectParam}%")
                      ->orWhere('title', 'like', "%{$cleanSubject}%");
                })->first();
        }

        if (!$subject) {
            return response()->json([
                'status' => 'error',
                'message' => "Subject not found for: {$subjectParam}",
            ], 404);
        }

        // 3. Resolve Chapter
        $chapter = Chapter::select(['id', 'grade_id', 'subject_id', 'chapter_number', 'title', 'pdf_path', 'ai_generated_notes', 'notes_generated_at', 'description'])
            ->where('grade_id', $grade->id)
            ->where('subject_id', $subject->id)
            ->where('chapter_number', $chapterNumber)
            ->first();

        if (!$chapter) {
            $chapter = Chapter::select(['id', 'grade_id', 'subject_id', 'chapter_number', 'title', 'pdf_path', 'ai_generated_notes', 'notes_generated_at', 'description'])
                ->where('subject_id', $subject->id)
                ->where('chapter_number', $chapterNumber)
                ->first();
        }

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => "Chapter number {$chapterNumber} not found for Grade {$grade->name} and Subject {$subject->title}",
            ], 404);
        }

        return $chapter;
    }
}
