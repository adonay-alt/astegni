<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ContactController extends Controller
{
    /**
     * Store a newly submitted contact message (Public).
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'message' => ['required', 'string', 'max:5000'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $contact = Contact::create([
            'name' => $request->input('name'),
            'email' => strtolower(trim($request->input('email'))),
            'message' => $request->input('message'),
            'status' => 'unread',
        ]);

        // Optional email notification (fails silently if mail server is unconfigured)
        try {
            if (config('mail.mailer') && config('mail.from.address')) {
                // Optional mail notification trigger if configured
            }
        } catch (\Throwable $e) {
            Log::warning('Contact form email notification failed: ' . $e->getMessage());
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Your message has been submitted successfully.',
            'data' => $contact,
        ], 201);
    }
}
