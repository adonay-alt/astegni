<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Grade;
use App\Models\NationalExam;
use App\Models\NationalExamQuestion;
use App\Models\NationalExamSubject;
use App\Models\NationalExamYear;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AdminNationalExamController extends Controller
{
    // ==========================================
    // NATIONAL EXAM ADMIN CRUD
    // ==========================================

    public function storeNationalExam(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'grade_id' => 'required|integer|exists:grades,id',
            'stream_id' => 'nullable|integer|exists:streams,id',
            'title' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $grade = Grade::find($request->grade_id);
        if ($grade && !$grade->supportsNationalExam()) {
            return response()->json([
                'status' => 'error',
                'message' => 'The selected grade does not support national exams.',
                'errors' => [
                    'grade_id' => ['The selected grade cannot be used for National Exams.'],
                ],
            ], 422);
        }

        if ($request->filled('stream_id')) {
            $stream = \App\Models\Stream::find($request->stream_id);
            if ($stream && (int) $stream->grade_id !== (int) $request->grade_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not belong to the specified grade.'],
                    ],
                ], 422);
            }
        }

        $exam = NationalExam::create($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'National exam created successfully',
            'data' => $exam->load(['grade', 'stream']),
        ], 201);
    }

    public function updateNationalExam(Request $request, $id): JsonResponse
    {
        $exam = NationalExam::find($id);

        if (!$exam) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'stream_id' => 'nullable|integer|exists:streams,id',
            'title' => 'sometimes|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $targetGradeId = (int) $request->input('grade_id', $exam->grade_id);

        $grade = Grade::find($targetGradeId);
        if ($grade && !$grade->supportsNationalExam()) {
            return response()->json([
                'status' => 'error',
                'message' => 'The selected grade does not support national exams.',
                'errors' => [
                    'grade_id' => ['The selected grade cannot be used for National Exams.'],
                ],
            ], 422);
        }

        $targetStreamId = $request->has('stream_id') ? $request->stream_id : $exam->stream_id;

        if ($targetStreamId !== null) {
            $stream = \App\Models\Stream::find($targetStreamId);
            if ($stream && (int) $stream->grade_id !== $targetGradeId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not belong to the specified grade.'],
                    ],
                ], 422);
            }
        }

        $exam->update($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'National exam updated successfully',
            'data' => $exam->fresh(['grade', 'stream']),
        ]);
    }

    public function deleteNationalExam($id): JsonResponse
    {
        $exam = NationalExam::find($id);

        if (!$exam) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam not found',
            ], 404);
        }

        $exam->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'National exam deleted successfully',
        ]);
    }
    
    
        // ==========================================
    // NATIONAL EXAM FULL IMPORT (JSON)
    // ==========================================

   public function importExam(Request $request): JsonResponse
{
    $data = $request->all();

    $structureValidator = Validator::make($data, [
        'national_exam' => 'required|string|max:255',
        'year' => 'required|integer|min:1900|max:2100',
        'grade_id' => 'required|integer|exists:grades,id',
        'stream' => 'nullable|in:0,1',
        'subject' => 'required|string|max:255',
        'questions' => 'required|array|min:1',
    ]);

    if ($structureValidator->fails()) {
        return response()->json([
            'status' => 'error',
            'message' => 'Invalid JSON structure',
            'errors' => $structureValidator->errors(),
        ], 422);
    }

    $grade = Grade::find($data['grade_id']);
    if ($grade && !$grade->supportsNationalExam()) {
        return response()->json([
            'status' => 'error',
            'message' => 'The selected grade does not support national exams.',
            'errors' => [
                'grade_id' => ['The selected grade cannot be used for National Exams.'],
            ],
        ], 422);
    }

    $streamId = null;
    if (isset($data['stream'])) {
        $streamName = ((string) $data['stream'] === '1') ? 'Natural Science' : 'Social Science';
        $stream = \App\Models\Stream::where('grade_id', $data['grade_id'])
            ->where('name', $streamName)
            ->first();
        $streamId = $stream?->id;

        if ($streamId === null) {
            return response()->json([
                'status' => 'error',
                'message' => 'No matching stream found for this grade.',
                'errors' => ['stream' => ["Could not find a '{$streamName}' stream for grade_id {$data['grade_id']}."]],
            ], 422);
        }
    }

    $errors = [];
    foreach ($data['questions'] as $index => $q) {
        $rowNumber = $index + 1;

        $questionValidator = Validator::make($q, [
            'question_number' => 'required|integer|min:1',
            'question' => 'required|string',
            'option_a' => 'nullable|string',
            'option_b' => 'nullable|string',
            'option_c' => 'nullable|string',
            'option_d' => 'nullable|string',
            'correct_answer' => 'required|string|in:option_a,option_b,option_c,option_d',
            'explanation' => 'nullable|string',
        ]);

        if ($questionValidator->fails()) {
            $errors["question_{$rowNumber}"] = $questionValidator->errors()->all();
        }
    }

    if (!empty($errors)) {
        return response()->json([
            'status' => 'error',
            'message' => 'Some questions failed validation. Nothing was saved.',
            'errors' => $errors,
        ], 422);
    }

    DB::beginTransaction();
    try {
        $exam = NationalExam::whereRaw('LOWER(title) = ?', [strtolower(trim($data['national_exam']))])
            ->where('grade_id', $data['grade_id'])
            ->first();

        if (!$exam) {
            $exam = NationalExam::create([
                'title' => trim($data['national_exam']),
                'grade_id' => $data['grade_id'],
                'stream_id' => $streamId,
            ]);
        }

        $examYear = NationalExamYear::where('national_exam_id', $exam->id)
            ->where('year', $data['year'])
            ->first();

        if (!$examYear) {
            $examYear = NationalExamYear::create([
                'national_exam_id' => $exam->id,
                'grade_id' => $exam->grade_id,
                'stream_id' => $exam->stream_id,
                'year' => $data['year'],
            ]);
        }

        $subject = NationalExamSubject::whereRaw('LOWER(name) = ?', [strtolower(trim($data['subject']))])
            ->where('national_exam_year_id', $examYear->id)
            ->first();

        if (!$subject) {
            $subject = NationalExamSubject::create([
                'national_exam_year_id' => $examYear->id,
                'national_exam_id' => $examYear->national_exam_id,
                'grade_id' => $examYear->grade_id,
                'stream_id' => $examYear->stream_id,
                'name' => trim($data['subject']),
            ]);
        }

        $saved = [];
        foreach ($data['questions'] as $q) {
            $saved[] = NationalExamQuestion::create([
                'national_exam_subject_id' => $subject->id,
                'national_exam_year_id' => $subject->national_exam_year_id,
                'national_exam_id' => $subject->national_exam_id,
                'grade_id' => $subject->grade_id,
                'stream_id' => $subject->stream_id,
                'question_number' => $q['question_number'],
                'question' => $q['question'],
                'option_a' => $q['option_a'] ?? null,
                'option_b' => $q['option_b'] ?? null,
                'option_c' => $q['option_c'] ?? null,
                'option_d' => $q['option_d'] ?? null,
                'correct_answer' => $q['correct_answer'],
                'explanation' => $q['explanation'] ?? null,
            ]);
        }

        DB::commit();

        return response()->json([
            'status' => 'success',
            'message' => count($saved) . ' questions imported successfully',
            'data' => [
                'national_exam' => $exam->title,
                'year' => $examYear->year,
                'subject' => $subject->name,
                'imported_count' => count($saved),
            ],
        ], 201);

    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'status' => 'error',
            'message' => 'Something went wrong while saving. Nothing was saved.',
        ], 500);
    }
}
    

    // ==========================================
    // NATIONAL EXAM YEAR ADMIN CRUD
    // ==========================================

    public function storeNationalExamYear(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'national_exam_id' => 'required|integer|exists:national_exams,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'stream_id' => 'sometimes|nullable|integer|exists:streams,id',
            'year' => 'required|integer|min:1900|max:2100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $exam = NationalExam::find($request->national_exam_id);

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$exam->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the national exam grade.'],
                ],
            ], 422);
        }

        $streamId = $exam->stream_id;
        if ($request->has('stream_id') && $request->stream_id !== null) {
            $stream = \App\Models\Stream::find($request->stream_id);
            if ($stream && (int)$stream->grade_id !== (int)$exam->grade_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not match the national exam grade.'],
                    ],
                ], 422);
            }
            if ($exam->stream_id !== null && (int)$request->stream_id !== (int)$exam->stream_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not match the national exam stream.'],
                    ],
                ], 422);
            }
            $streamId = $request->stream_id;
        }

        $examYear = NationalExamYear::create([
            'national_exam_id' => $exam->id,
            'grade_id' => $exam->grade_id,
            'stream_id' => $streamId,
            'year' => $request->year,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'National exam year created successfully',
            'data' => $examYear->load(['grade', 'stream', 'nationalExam']),
        ], 201);
    }

    public function updateNationalExamYear(Request $request, $id): JsonResponse
    {
        $examYear = NationalExamYear::find($id);

        if (!$examYear) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam year not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'national_exam_id' => 'sometimes|integer|exists:national_exams,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'stream_id' => 'sometimes|nullable|integer|exists:streams,id',
            'year' => 'sometimes|integer|min:1900|max:2100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('national_exam_id')) {
            $exam = NationalExam::find($request->national_exam_id);
            if ($request->has('grade_id') && (int)$request->grade_id !== (int)$exam->grade_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'grade_id' => ['The selected grade does not match the national exam grade.'],
                    ],
                ], 422);
            }
            $examYear->national_exam_id = $exam->id;
            $examYear->grade_id = $exam->grade_id;
            $examYear->stream_id = $exam->stream_id;
        }

        if ($request->has('stream_id')) {
            if ($request->stream_id !== null) {
                $stream = \App\Models\Stream::find($request->stream_id);
                if ($stream && (int)$stream->grade_id !== (int)$examYear->grade_id) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Validation failed',
                        'errors' => [
                            'stream_id' => ['The selected stream does not match the national exam grade.'],
                        ],
                    ], 422);
                }
            }
            $examYear->stream_id = $request->stream_id;
        }

        if ($request->has('year')) {
            $examYear->year = $request->year;
        }

        $examYear->save();

        return response()->json([
            'status' => 'success',
            'message' => 'National exam year updated successfully',
            'data' => $examYear->fresh(['grade', 'stream', 'nationalExam']),
        ]);
    }

    public function deleteNationalExamYear($id): JsonResponse
    {
        $examYear = NationalExamYear::find($id);

        if (!$examYear) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam year not found',
            ], 404);
        }

        $examYear->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'National exam year deleted successfully',
        ]);
    }

    // ==========================================
    // NATIONAL EXAM SUBJECT ADMIN CRUD
    // ==========================================

    public function storeNationalExamSubject(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'national_exam_year_id' => 'required|integer|exists:national_exam_years,id',
            'national_exam_id' => 'sometimes|integer|exists:national_exams,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'stream_id' => 'sometimes|nullable|integer|exists:streams,id',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $examYear = NationalExamYear::find($request->national_exam_year_id);

        if ($request->has('national_exam_id') && (int)$request->national_exam_id !== (int)$examYear->national_exam_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'national_exam_id' => ['The selected national exam does not match the specified exam year.'],
                ],
            ], 422);
        }

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$examYear->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified exam year.'],
                ],
            ], 422);
        }

        $streamId = $examYear->stream_id;
        if ($request->has('stream_id') && $request->stream_id !== null) {
            $stream = \App\Models\Stream::find($request->stream_id);
            if ($stream && (int)$stream->grade_id !== (int)$examYear->grade_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not match the specified exam year grade.'],
                    ],
                ], 422);
            }
            if ($examYear->stream_id !== null && (int)$request->stream_id !== (int)$examYear->stream_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not match the exam year stream.'],
                    ],
                ], 422);
            }
            $streamId = $request->stream_id;
        }

        $subject = NationalExamSubject::create([
            'national_exam_year_id' => $examYear->id,
            'national_exam_id' => $examYear->national_exam_id,
            'grade_id' => $examYear->grade_id,
            'stream_id' => $streamId,
            'name' => $request->name,
            'description' => $request->description,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'National exam subject created successfully',
            'data' => $subject->load(['grade', 'stream', 'nationalExam', 'nationalExamYear']),
        ], 201);
    }

    public function updateNationalExamSubject(Request $request, $id): JsonResponse
    {
        $subject = NationalExamSubject::find($id);

        if (!$subject) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam subject not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'national_exam_year_id' => 'sometimes|integer|exists:national_exam_years,id',
            'name' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('national_exam_year_id')) {
            $examYear = NationalExamYear::find($request->national_exam_year_id);
            $subject->national_exam_year_id = $examYear->id;
            $subject->national_exam_id = $examYear->national_exam_id;
            $subject->grade_id = $examYear->grade_id;
            $subject->stream_id = $examYear->stream_id;
        }

        if ($request->has('stream_id')) {
            if ($request->stream_id !== null) {
                $stream = \App\Models\Stream::find($request->stream_id);
                if ($stream && (int)$stream->grade_id !== (int)$subject->grade_id) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Validation failed',
                        'errors' => [
                            'stream_id' => ['The selected stream does not match the subject grade.'],
                        ],
                    ], 422);
                }
            }
            $subject->stream_id = $request->stream_id;
        }

        if ($request->has('name')) {
            $subject->name = $request->name;
        }
        if ($request->has('description')) {
            $subject->description = $request->description;
        }

        $subject->save();

        return response()->json([
            'status' => 'success',
            'message' => 'National exam subject updated successfully',
            'data' => $subject->fresh(['grade', 'stream', 'nationalExam', 'nationalExamYear']),
        ]);
    }

    public function deleteNationalExamSubject($id): JsonResponse
    {
        $subject = NationalExamSubject::find($id);

        if (!$subject) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam subject not found',
            ], 404);
        }

        $subject->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'National exam subject deleted successfully',
        ]);
    }

    // ==========================================
    // NATIONAL EXAM QUESTION ADMIN CRUD
    // ==========================================

    public function storeNationalExamQuestion(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'national_exam_subject_id' => 'required|integer|exists:national_exam_subjects,id',
            'national_exam_year_id' => 'sometimes|integer|exists:national_exam_years,id',
            'national_exam_id' => 'sometimes|integer|exists:national_exams,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'stream_id' => 'sometimes|nullable|integer|exists:streams,id',
            'question_number' => 'required|integer|min:1',
            'question' => 'required|string',
            'option_a' => 'nullable|string',
            'option_b' => 'nullable|string',
            'option_c' => 'nullable|string',
            'option_d' => 'nullable|string',
            'correct_answer' => 'required|string',
            'explanation' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $subject = NationalExamSubject::find($request->national_exam_subject_id);

        if ($request->has('national_exam_year_id') && (int)$request->national_exam_year_id !== (int)$subject->national_exam_year_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'national_exam_year_id' => ['The selected national exam year does not match the specified subject.'],
                ],
            ], 422);
        }

        if ($request->has('national_exam_id') && (int)$request->national_exam_id !== (int)$subject->national_exam_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'national_exam_id' => ['The selected national exam does not match the specified subject.'],
                ],
            ], 422);
        }

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$subject->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified subject.'],
                ],
            ], 422);
        }

        $streamId = $subject->stream_id;
        if ($request->has('stream_id') && $request->stream_id !== null) {
            $stream = \App\Models\Stream::find($request->stream_id);
            if ($stream && (int)$stream->grade_id !== (int)$subject->grade_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not match the subject grade.'],
                    ],
                ], 422);
            }
            if ($subject->stream_id !== null && (int)$request->stream_id !== (int)$subject->stream_id) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Validation failed',
                    'errors' => [
                        'stream_id' => ['The selected stream does not match the subject stream.'],
                    ],
                ], 422);
            }
            $streamId = $request->stream_id;
        }

        $question = NationalExamQuestion::create([
            'national_exam_subject_id' => $subject->id,
            'national_exam_year_id' => $subject->national_exam_year_id,
            'national_exam_id' => $subject->national_exam_id,
            'grade_id' => $subject->grade_id,
            'stream_id' => $streamId,
            'question_number' => $request->question_number,
            'question' => $request->question,
            'option_a' => $request->option_a,
            'option_b' => $request->option_b,
            'option_c' => $request->option_c,
            'option_d' => $request->option_d,
            'correct_answer' => $request->correct_answer,
            'explanation' => $request->explanation,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'National exam question created successfully',
            'data' => $question->load(['grade', 'stream', 'nationalExam', 'nationalExamYear', 'nationalExamSubject']),
        ], 201);
    }

    public function updateNationalExamQuestion(Request $request, $id): JsonResponse
    {
        $question = NationalExamQuestion::find($id);

        if (!$question) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam question not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'question_number' => 'sometimes|integer|min:1',
            'question' => 'sometimes|string',
            'option_a' => 'nullable|string',
            'option_b' => 'nullable|string',
            'option_c' => 'nullable|string',
            'option_d' => 'nullable|string',
            'correct_answer' => 'sometimes|string',
            'explanation' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $question->update($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'National exam question updated successfully',
            'data' => $question->fresh(['grade', 'stream', 'nationalExam', 'nationalExamYear', 'nationalExamSubject']),
        ]);
    }

    public function deleteNationalExamQuestion($id): JsonResponse
    {
        $question = NationalExamQuestion::find($id);

        if (!$question) {
            return response()->json([
                'status' => 'error',
                'message' => 'National exam question not found',
            ], 404);
        }

        $question->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'National exam question deleted successfully',
        ]);
    }
}
