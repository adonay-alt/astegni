<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Chapter;
use App\Models\Grade;
use App\Models\Note;
use App\Models\Quiz;
use App\Models\QuizQuestion;
use App\Models\Resource;
use App\Models\Textbook;
use App\Models\Video;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class AdminLearningController extends Controller
{
    // ==========================================
    // CHAPTER ADMIN CRUD
    // ==========================================

    public function storeChapter(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'grade_id' => 'required|integer|exists:grades,id',
            'subject_id' => 'required|integer|exists:subjects,id',
            'title' => 'required|string|max:255',
            'chapter_number' => 'required|integer|min:1',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $grade = Grade::find($request->grade_id);
        if ($grade && !$grade->supportsLearning()) {
            return response()->json([
                'status' => 'error',
                'message' => 'The selected grade does not support normal learning content.',
                'errors' => [
                    'grade_id' => ['The selected grade cannot be associated with normal learning content.'],
                ],
            ], 422);
        }

        $chapter = Chapter::create($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'Chapter created successfully',
            'data' => $chapter->load(['grade', 'subject']),
        ], 201);
    }

    public function updateChapter(Request $request, $id): JsonResponse
    {
        $chapter = Chapter::find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'subject_id' => 'sometimes|integer|exists:subjects,id',
            'title' => 'sometimes|string|max:255',
            'chapter_number' => 'sometimes|integer|min:1',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('grade_id')) {
            $grade = Grade::find($request->grade_id);
            if ($grade && !$grade->supportsLearning()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'The selected grade does not support normal learning content.',
                    'errors' => [
                        'grade_id' => ['The selected grade cannot be associated with normal learning content.'],
                    ],
                ], 422);
            }
        }

        $chapter->update($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'Chapter updated successfully',
            'data' => $chapter->fresh(['grade', 'subject']),
        ]);
    }

    public function deleteChapter($id): JsonResponse
    {
        $chapter = Chapter::find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        $chapter->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Chapter deleted successfully',
        ]);
    }

    /**
     * Admin action to trigger Google Gemini AI note generation for a chapter.
     */
    public function generateChapterNotes(Request $request, $id): JsonResponse
    {
        $chapter = Chapter::with(['grade', 'subject', 'textbooks'])->find($id);

        if (!$chapter) {
            return response()->json([
                'status' => 'error',
                'message' => 'Chapter not found',
            ], 404);
        }

        $hasTextbook = $chapter->pdf_path || $chapter->textbooks()->count() > 0;
        if (!$hasTextbook) {
            return response()->json([
                'status' => 'error',
                'message' => 'No PDF file attached to this chapter or its associated textbooks.',
            ], 422);
        }

        // Return existing notes if already generated and force/overwrite is not requested
        if (!empty($chapter->ai_generated_notes) && !$request->boolean('force') && !$request->boolean('overwrite')) {
            return response()->json([
                'status' => 'success',
                'message' => 'Notes already exist for this chapter. Pass force=true or overwrite=true to regenerate.',
                'data' => [
                    'chapter_id' => $chapter->id,
                    'title' => $chapter->title,
                    'ai_generated_notes' => $chapter->ai_generated_notes,
                    'ai_generated_notes_html' => \Illuminate\Support\Str::markdown($chapter->ai_generated_notes),
                    'notes_generated_at' => $chapter->notes_generated_at,
                    'already_exists' => true,
                ]
            ]);
        }

        if ($request->boolean('sync')) {
            try {
                $job = new \App\Jobs\GenerateChapterNotesJob($chapter);
                $job->handle(app(\App\Services\GeminiService::class));
                $chapter->refresh();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Chapter notes generated synchronously via Gemini AI.',
                    'data' => [
                        'chapter_id' => $chapter->id,
                        'title' => $chapter->title,
                        'ai_generated_notes' => $chapter->ai_generated_notes,
                        'ai_generated_notes_html' => \Illuminate\Support\Str::markdown($chapter->ai_generated_notes ?? ''),
                        'notes_generated_at' => $chapter->notes_generated_at,
                    ]
                ]);
            } catch (\Exception $e) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Failed generating notes: ' . $e->getMessage(),
                ], 500);
            }
        }

        \App\Jobs\GenerateChapterNotesJob::dispatch($chapter);

        return response()->json([
            'status' => 'success',
            'message' => 'Gemini AI is generating notes in the background. Refresh in a moment.',
            'data' => [
                'chapter_id' => $chapter->id,
                'title' => $chapter->title,
                'status' => 'processing',
            ]
        ]);
    }

    /**
     * Admin action to trigger Google Gemini AI quiz generation or regeneration for a chapter.
     */
    public function generateChapterQuiz(Request $request, $id): JsonResponse
    {
        return app(\App\Http\Controllers\Api\ChapterController::class)->generateQuiz($request, $id);
    }

    // ==========================================
    // NOTE ADMIN CRUD
    // ==========================================

    public function storeNote(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'chapter_id' => 'required|integer|exists:chapters,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'subject_id' => 'sometimes|integer|exists:subjects,id',
            'title' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $chapter = Chapter::find($request->chapter_id);

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$chapter->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->has('subject_id') && (int)$request->subject_id !== (int)$chapter->subject_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'subject_id' => ['The selected subject does not match the specified chapter.'],
                ],
            ], 422);
        }

        $note = Note::create([
            'chapter_id' => $chapter->id,
            'grade_id' => $chapter->grade_id,
            'subject_id' => $chapter->subject_id,
            'title' => $request->title,
            'content' => $request->content,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Note created successfully',
            'data' => $note->load(['grade', 'subject', 'chapter']),
        ], 201);
    }

    public function updateNote(Request $request, $id): JsonResponse
    {
        $note = Note::find($id);

        if (!$note) {
            return response()->json([
                'status' => 'error',
                'message' => 'Note not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'chapter_id' => 'sometimes|integer|exists:chapters,id',
            'title' => 'sometimes|string|max:255',
            'content' => 'sometimes|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('chapter_id')) {
            $chapter = Chapter::find($request->chapter_id);
            $note->chapter_id = $chapter->id;
            $note->grade_id = $chapter->grade_id;
            $note->subject_id = $chapter->subject_id;
        }

        if ($request->has('title')) {
            $note->title = $request->title;
        }
        if ($request->has('content')) {
            $note->content = $request->content;
        }

        $note->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Note updated successfully',
            'data' => $note->fresh(['grade', 'subject', 'chapter']),
        ]);
    }

    public function deleteNote($id): JsonResponse
    {
        $note = Note::find($id);

        if (!$note) {
            return response()->json([
                'status' => 'error',
                'message' => 'Note not found',
            ], 404);
        }

        $note->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Note deleted successfully',
        ]);
    }

    // ==========================================
    // TEXTBOOK ADMIN CRUD
    // ==========================================

    public function storeTextbook(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'chapter_id' => 'required|integer|exists:chapters,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'subject_id' => 'sometimes|integer|exists:subjects,id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'file' => ['required_without:file_url', 'file', 'mimes:pdf', 'max:20480'],
            'file_url' => 'required_without:file|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $chapter = Chapter::find($request->chapter_id);

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$chapter->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->has('subject_id') && (int)$request->subject_id !== (int)$chapter->subject_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'subject_id' => ['The selected subject does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('textbooks', 'public');
        } else {
            $filePath = $request->file_url;
        }

        $textbook = Textbook::create([
            'chapter_id' => $chapter->id,
            'grade_id' => $chapter->grade_id,
            'subject_id' => $chapter->subject_id,
            'title' => $request->title,
            'description' => $request->description,
            'file_url' => $filePath,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Textbook created successfully',
            'data' => $textbook->load(['grade', 'subject', 'chapter']),
        ], 201);
    }

    public function updateTextbook(Request $request, $id): JsonResponse
    {
        $textbook = Textbook::find($id);

        if (!$textbook) {
            return response()->json([
                'status' => 'error',
                'message' => 'Textbook not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'chapter_id' => 'sometimes|integer|exists:chapters,id',
            'title' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'file' => ['nullable', 'file', 'mimes:pdf', 'max:20480'],
            'file_url' => 'sometimes|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('chapter_id')) {
            $chapter = Chapter::find($request->chapter_id);
            $textbook->chapter_id = $chapter->id;
            $textbook->grade_id = $chapter->grade_id;
            $textbook->subject_id = $chapter->subject_id;
        }

        if ($request->has('title')) {
            $textbook->title = $request->title;
        }
        if ($request->has('description')) {
            $textbook->description = $request->description;
        }

        if ($request->hasFile('file')) {
            $oldPath = $textbook->getRawOriginal('file_url');
            if ($oldPath && Storage::disk('public')->exists($oldPath)) {
                Storage::disk('public')->delete($oldPath);
            }
            $textbook->file_url = $request->file('file')->store('textbooks', 'public');
        } elseif ($request->has('file_url')) {
            $textbook->file_url = $request->file_url;
        }

        $textbook->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Textbook updated successfully',
            'data' => $textbook->fresh(['grade', 'subject', 'chapter']),
        ]);
    }

    public function deleteTextbook($id): JsonResponse
    {
        $textbook = Textbook::find($id);

        if (!$textbook) {
            return response()->json([
                'status' => 'error',
                'message' => 'Textbook not found',
            ], 404);
        }

        $rawPath = $textbook->getRawOriginal('file_url');
        if ($rawPath && Storage::disk('public')->exists($rawPath)) {
            Storage::disk('public')->delete($rawPath);
        }

        $textbook->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Textbook deleted successfully',
        ]);
    }

    // ==========================================
    // RESOURCE ADMIN CRUD
    // ==========================================

    public function storeResource(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'chapter_id' => 'required|integer|exists:chapters,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'subject_id' => 'sometimes|integer|exists:subjects,id',
            'title' => 'required|string|max:255',
            'type' => 'nullable|string',
            'description' => 'nullable|string',
            'file' => ['required_without:url', 'file', 'mimes:pdf,doc,docx,ppt,pptx,xls,xlsx,zip', 'max:20480'],
            'url' => 'required_without:file|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $chapter = Chapter::find($request->chapter_id);

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$chapter->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->has('subject_id') && (int)$request->subject_id !== (int)$chapter->subject_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'subject_id' => ['The selected subject does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filePath = $file->store('resources', 'public');
            $type = $request->input('type', strtolower($file->getClientOriginalExtension()));
        } else {
            $filePath = $request->url;
            $type = $request->input('type', 'link');
        }

        $resource = Resource::create([
            'chapter_id' => $chapter->id,
            'grade_id' => $chapter->grade_id,
            'subject_id' => $chapter->subject_id,
            'title' => $request->title,
            'type' => $type,
            'url' => $filePath,
            'description' => $request->description,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Resource created successfully',
            'data' => $resource->load(['grade', 'subject', 'chapter']),
        ], 201);
    }

    public function updateResource(Request $request, $id): JsonResponse
    {
        $resource = Resource::find($id);

        if (!$resource) {
            return response()->json([
                'status' => 'error',
                'message' => 'Resource not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'chapter_id' => 'sometimes|integer|exists:chapters,id',
            'title' => 'sometimes|string|max:255',
            'type' => 'nullable|string',
            'description' => 'nullable|string',
            'file' => ['nullable', 'file', 'mimes:pdf,doc,docx,ppt,pptx,xls,xlsx,zip', 'max:20480'],
            'url' => 'sometimes|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('chapter_id')) {
            $chapter = Chapter::find($request->chapter_id);
            $resource->chapter_id = $chapter->id;
            $resource->grade_id = $chapter->grade_id;
            $resource->subject_id = $chapter->subject_id;
        }

        if ($request->has('title')) {
            $resource->title = $request->title;
        }
        if ($request->has('description')) {
            $resource->description = $request->description;
        }
        if ($request->has('type')) {
            $resource->type = $request->type;
        }

        if ($request->hasFile('file')) {
            $oldPath = $resource->getRawOriginal('url');
            if ($oldPath && Storage::disk('public')->exists($oldPath)) {
                Storage::disk('public')->delete($oldPath);
            }
            $file = $request->file('file');
            $resource->url = $file->store('resources', 'public');
            if (!$request->has('type')) {
                $resource->type = strtolower($file->getClientOriginalExtension());
            }
        } elseif ($request->has('url')) {
            $resource->url = $request->url;
        }

        $resource->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Resource updated successfully',
            'data' => $resource->fresh(['grade', 'subject', 'chapter']),
        ]);
    }

    public function deleteResource($id): JsonResponse
    {
        $resource = Resource::find($id);

        if (!$resource) {
            return response()->json([
                'status' => 'error',
                'message' => 'Resource not found',
            ], 404);
        }

        $rawPath = $resource->getRawOriginal('url');
        if ($rawPath && Storage::disk('public')->exists($rawPath)) {
            Storage::disk('public')->delete($rawPath);
        }

        $resource->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Resource deleted successfully',
        ]);
    }

    // ==========================================
    // VIDEO ADMIN CRUD
    // ==========================================

    public function storeVideo(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'chapter_id' => 'required|integer|exists:chapters,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'subject_id' => 'sometimes|integer|exists:subjects,id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'video_url' => 'required|url',
            'thumbnail_url' => 'nullable|url',
            'duration' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $chapter = Chapter::find($request->chapter_id);

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$chapter->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->has('subject_id') && (int)$request->subject_id !== (int)$chapter->subject_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'subject_id' => ['The selected subject does not match the specified chapter.'],
                ],
            ], 422);
        }

        $video = Video::create([
            'chapter_id' => $chapter->id,
            'grade_id' => $chapter->grade_id,
            'subject_id' => $chapter->subject_id,
            'title' => $request->title,
            'description' => $request->description,
            'video_url' => $request->video_url,
            'thumbnail_url' => $request->thumbnail_url,
            'duration' => $request->duration,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Video created successfully',
            'data' => $video->load(['grade', 'subject', 'chapter']),
        ], 201);
    }

    public function updateVideo(Request $request, $id): JsonResponse
    {
        $video = Video::find($id);

        if (!$video) {
            return response()->json([
                'status' => 'error',
                'message' => 'Video not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'title' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'video_url' => 'sometimes|url',
            'thumbnail_url' => 'nullable|url',
            'duration' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $video->update($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'Video updated successfully',
            'data' => $video->fresh(['grade', 'subject', 'chapter']),
        ]);
    }

    public function deleteVideo($id): JsonResponse
    {
        $video = Video::find($id);

        if (!$video) {
            return response()->json([
                'status' => 'error',
                'message' => 'Video not found',
            ], 404);
        }

        $video->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Video deleted successfully',
        ]);
    }

    // ==========================================
    // QUIZ ADMIN CRUD
    // ==========================================

    public function storeQuiz(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'chapter_id' => 'required|integer|exists:chapters,id',
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'subject_id' => 'sometimes|integer|exists:subjects,id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $chapter = Chapter::find($request->chapter_id);

        if ($request->has('grade_id') && (int)$request->grade_id !== (int)$chapter->grade_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['The selected grade does not match the specified chapter.'],
                ],
            ], 422);
        }

        if ($request->has('subject_id') && (int)$request->subject_id !== (int)$chapter->subject_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'subject_id' => ['The selected subject does not match the specified chapter.'],
                ],
            ], 422);
        }

        $quiz = Quiz::create([
            'chapter_id' => $chapter->id,
            'grade_id' => $chapter->grade_id,
            'subject_id' => $chapter->subject_id,
            'title' => $request->title,
            'description' => $request->description,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Quiz created successfully',
            'data' => $quiz->load(['grade', 'subject', 'chapter', 'questions']),
        ], 201);
    }

    public function updateQuiz(Request $request, $id): JsonResponse
    {
        $quiz = Quiz::find($id);

        if (!$quiz) {
            return response()->json([
                'status' => 'error',
                'message' => 'Quiz not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'title' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $quiz->update($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'Quiz updated successfully',
            'data' => $quiz->fresh(['grade', 'subject', 'chapter', 'questions']),
        ]);
    }

    public function deleteQuiz($id): JsonResponse
    {
        $quiz = Quiz::find($id);

        if (!$quiz) {
            return response()->json([
                'status' => 'error',
                'message' => 'Quiz not found',
            ], 404);
        }

        $quiz->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Quiz deleted successfully',
        ]);
    }

    // ==========================================
    // QUIZ QUESTION ADMIN CRUD
    // ==========================================

    public function storeQuizQuestion(Request $request, $quiz_id): JsonResponse
    {
        $quiz = Quiz::find($quiz_id);

        if (!$quiz) {
            return response()->json([
                'status' => 'error',
                'message' => 'Quiz not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'question' => 'required|string',
            'option_a' => 'required|string',
            'option_b' => 'required|string',
            'option_c' => 'required|string',
            'option_d' => 'required|string',
            'correct_answer' => 'required|string|in:option_a,option_b,option_c,option_d',
            'explanation' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $question = QuizQuestion::create(array_merge(
            $validator->validated(),
            ['quiz_id' => $quiz->id]
        ));

        return response()->json([
            'status' => 'success',
            'message' => 'Quiz question created successfully',
            'data' => $question,
        ], 201);
    }

    public function updateQuizQuestion(Request $request, $id): JsonResponse
    {
        $question = QuizQuestion::find($id);

        if (!$question) {
            return response()->json([
                'status' => 'error',
                'message' => 'Quiz question not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'question' => 'sometimes|string',
            'option_a' => 'sometimes|string',
            'option_b' => 'sometimes|string',
            'option_c' => 'sometimes|string',
            'option_d' => 'sometimes|string',
            'correct_answer' => 'sometimes|string|in:option_a,option_b,option_c,option_d',
            'explanation' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $question->update($validator->validated());

        return response()->json([
            'status' => 'success',
            'message' => 'Quiz question updated successfully',
            'data' => $question->fresh(),
        ]);
    }

    public function deleteQuizQuestion($id): JsonResponse
    {
        $question = QuizQuestion::find($id);

        if (!$question) {
            return response()->json([
                'status' => 'error',
                'message' => 'Quiz question not found',
            ], 404);
        }

        $question->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Quiz question deleted successfully',
        ]);
    }
}
