<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LatestUpdate;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class LatestUpdatesController extends Controller
{
    /**
     * Display a listing of active latest updates.
     *
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        $updates = LatestUpdate::where('is_active', true)
            ->orderByRaw('COALESCE(published_at, created_at) DESC')
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $updates,
        ], 200);
    }

    /**
     * Display a single active update.
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function show($id): JsonResponse
    {
        $update = LatestUpdate::find($id);

        if (!$update || !$update->is_active) {
            return response()->json([
                'status' => 'error',
                'message' => 'Latest update not found',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'data' => $update,
        ], 200);
    }

    /**
     * Store a newly created latest update in storage (Admin only).
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'title' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'image' => ['nullable', 'file', 'image', 'mimes:jpeg,jpg,png,webp', 'max:5120'],
            'is_active' => ['nullable', 'boolean'],
            'published_at' => ['nullable', 'date'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('updates', 'public');
        }

        $update = LatestUpdate::create([
            'title' => $request->title,
            'description' => $request->description,
            'image_path' => $imagePath,
            'is_active' => $request->has('is_active') ? $request->boolean('is_active') : true,
            'published_at' => $request->published_at ?? now(),
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Latest update created successfully',
            'data' => $update,
        ], 201);
    }

    /**
     * Update the specified latest update in storage (Admin only).
     *
     * @param Request $request
     * @param int|string $id
     * @return JsonResponse
     */
    public function update(Request $request, $id): JsonResponse
    {
        $update = LatestUpdate::find($id);

        if (!$update) {
            return response()->json([
                'status' => 'error',
                'message' => 'Latest update not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'title' => ['sometimes', 'required', 'string', 'max:255'],
            'description' => ['sometimes', 'required', 'string'],
            'image' => ['nullable', 'file', 'image', 'mimes:jpeg,jpg,png,webp', 'max:5120'],
            'is_active' => ['nullable', 'boolean'],
            'published_at' => ['nullable', 'date'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->hasFile('image')) {
            // Delete old image if present
            if ($update->image_path && Storage::disk('public')->exists($update->image_path)) {
                Storage::disk('public')->delete($update->image_path);
            }
            $update->image_path = $request->file('image')->store('updates', 'public');
        }

        if ($request->has('title')) {
            $update->title = $request->title;
        }

        if ($request->has('description')) {
            $update->description = $request->description;
        }

        if ($request->has('is_active')) {
            $update->is_active = $request->boolean('is_active');
        }

        if ($request->has('published_at')) {
            $update->published_at = $request->published_at;
        }

        $update->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Latest update updated successfully',
            'data' => $update->fresh(),
        ], 200);
    }

    /**
     * Remove the specified latest update from storage (Admin only).
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function destroy($id): JsonResponse
    {
        $update = LatestUpdate::find($id);

        if (!$update) {
            return response()->json([
                'status' => 'error',
                'message' => 'Latest update not found',
            ], 404);
        }

        if ($update->image_path && Storage::disk('public')->exists($update->image_path)) {
            Storage::disk('public')->delete($update->image_path);
        }

        $update->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Latest update deleted successfully',
        ], 200);
    }
}
