<?php
namespace App\Http\Controllers\Api; 

use App\Http\Controllers\Controller; 
use App\Models\Blog;
use Illuminate\Http\JsonResponse;

class BlogController extends Controller
{
    public function index(): JsonResponse
    {
        $blogs = Blog::latest()->get();
        return response()->json([
            'status' => 'success',
            'data' => $blogs
        ], 200);
    }

    /**
     * Display a single blog/news post.
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function show($id): JsonResponse
    {
        $blog = Blog::find($id);

        if (!$blog) {
            return response()->json([
                'status' => 'error',
                'message' => 'Blog post not found',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'data' => $blog,
        ], 200);
    }
}