<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\TutorProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AdminTutorController extends Controller
{
    /**
     * Update tutor profile approval status.
     * Accessible only by authorized admin.
     * Generates an in-app notification for the applicant on actual status transitions.
     *
     * @param Request $request
     * @param int $id
     * @return JsonResponse
     */
    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $user = $request->user();

        if (!$user || !$user->is_admin) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthorized. Admin privileges required.',
            ], 403);
        }

        $tutor = TutorProfile::with(['user', 'subjects', 'grades'])->find($id);

        if (!$tutor) {
            return response()->json([
                'status' => 'error',
                'message' => 'Tutor profile not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'status' => 'required|string|in:approved,rejected,pending',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $oldStatus = $tutor->status;
        $newStatus = $request->status;

        DB::transaction(function () use ($tutor, $oldStatus, $newStatus) {
            $tutor->update([
                'status' => $newStatus,
            ]);

            // Only generate notification on an actual status change
            if ($oldStatus !== $newStatus) {
                if ($newStatus === 'approved') {
                    Notification::create([
                        'user_id' => $tutor->user_id,
                        'type' => 'tutor_application',
                        'title' => 'Tutor Application Accepted',
                        'message' => 'Congratulations! Your tutor application has been approved. You can now access your tutor features.',
                        'data' => [
                            'tutor_profile_id' => $tutor->id,
                            'status' => 'approved',
                        ],
                    ]);
                } elseif ($newStatus === 'rejected') {
                    Notification::create([
                        'user_id' => $tutor->user_id,
                        'type' => 'tutor_application',
                        'title' => 'Tutor Application Rejected',
                        'message' => 'Your tutor application has been rejected.',
                        'data' => [
                            'tutor_profile_id' => $tutor->id,
                            'status' => 'rejected',
                        ],
                    ]);
                }
            }
        });

        $tutor->refresh();
        $tutor->load(['subjects', 'grades']);

        return response()->json([
            'status' => 'success',
            'message' => "Tutor status updated to {$request->status}",
            'data' => [
                'id' => $tutor->id,
                'user_id' => $tutor->user_id,
                'name' => $tutor->user ? $tutor->user->name : null,
                'email' => $tutor->user ? $tutor->user->email : null,
                'phone' => $tutor->phone,
                'gender' => $tutor->gender,
                'city' => $tutor->city,
                'image' => $tutor->image_url,
                'status' => $tutor->status,
                'subject' => $tutor->subjects?->pluck('title')?->implode(', ') ?? '',
                'grade' => $tutor->grades?->pluck('name')?->implode(', ') ?? '',
                'subjects' => $tutor->subjects ? $tutor->subjects->map(fn($s) => ['id' => $s->id, 'name' => $s->title, 'title' => $s->title])->values() : [],
                'grades' => $tutor->grades ? $tutor->grades->map(fn($g) => ['id' => $g->id, 'name' => $g->name])->values() : [],
            ],
        ]);
    }
}
