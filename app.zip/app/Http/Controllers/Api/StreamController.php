<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Grade;
use App\Models\Stream;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StreamController extends Controller
{
    /**
     * Display a listing of streams.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        $query = Stream::with(['grade']);

        if ($request->has('grade_id') && $request->grade_id !== null) {
            $query->where('grade_id', $request->grade_id);
        }

        $streams = $query->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Streams retrieved successfully',
            'data' => $streams,
        ]);
    }

    /**
     * Display the specified stream.
     *
     * @param int $id
     * @return JsonResponse
     */
    public function show(int $id): JsonResponse
    {
        $stream = Stream::with(['grade', 'subjects'])->find($id);

        if (!$stream) {
            return response()->json([
                'status' => 'error',
                'message' => 'Stream not found',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Stream retrieved successfully',
            'data' => $stream,
        ]);
    }

    /**
     * Get streams by grade ID.
     *
     * @param int $grade_id
     * @return JsonResponse
     */
    public function getByGrade(int $grade_id): JsonResponse
    {
        $grade = Grade::find($grade_id);

        if (!$grade) {
            return response()->json([
                'status' => 'error',
                'message' => 'Grade not found',
            ], 404);
        }

        $streams = Stream::where('grade_id', $grade_id)->with(['grade'])->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Streams retrieved successfully',
            'data' => $streams,
        ]);
    }

    /**
     * Store a newly created stream (Admin only).
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'grade_id' => 'required|integer|exists:grades,id',
            'name' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $grade = Grade::find($request->grade_id);

        // Reject streams for Grade 9 and Grade 10
        if ($grade && (str_contains(strtolower($grade->name), '9') || str_contains(strtolower($grade->name), '10'))) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['Streams are only allowed for Grade 11 and Grade 12.'],
                ],
            ], 422);
        }

        // Check uniqueness constraint per grade
        $existing = Stream::where('grade_id', $request->grade_id)
            ->where('name', $request->name)
            ->first();

        if ($existing) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'name' => ['A stream with this name already exists for the selected grade.'],
                ],
            ], 422);
        }

        $stream = Stream::create([
            'grade_id' => $request->grade_id,
            'name' => $request->name,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Stream created successfully',
            'data' => $stream->load('grade'),
        ], 201);
    }

    /**
     * Update the specified stream (Admin only).
     *
     * @param Request $request
     * @param int $id
     * @return JsonResponse
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $stream = Stream::find($id);

        if (!$stream) {
            return response()->json([
                'status' => 'error',
                'message' => 'Stream not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'grade_id' => 'sometimes|integer|exists:grades,id',
            'name' => 'sometimes|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $targetGradeId = $request->input('grade_id', $stream->grade_id);
        $targetName = $request->input('name', $stream->name);

        $grade = Grade::find($targetGradeId);

        if ($grade && (str_contains(strtolower($grade->name), '9') || str_contains(strtolower($grade->name), '10'))) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'grade_id' => ['Streams are only allowed for Grade 11 and Grade 12.'],
                ],
            ], 422);
        }

        // Uniqueness check excluding current stream
        $existing = Stream::where('grade_id', $targetGradeId)
            ->where('name', $targetName)
            ->where('id', '!=', $stream->id)
            ->first();

        if ($existing) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => [
                    'name' => ['A stream with this name already exists for the selected grade.'],
                ],
            ], 422);
        }

        $stream->update([
            'grade_id' => $targetGradeId,
            'name' => $targetName,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Stream updated successfully',
            'data' => $stream->fresh('grade'),
        ]);
    }

    /**
     * Delete the specified stream (Admin only).
     *
     * @param int $id
     * @return JsonResponse
     */
    public function delete(int $id): JsonResponse
    {
        $stream = Stream::find($id);

        if (!$stream) {
            return response()->json([
                'status' => 'error',
                'message' => 'Stream not found',
            ], 404);
        }

        $stream->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Stream deleted successfully',
        ]);
    }
}
