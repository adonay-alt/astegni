<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\PageSection;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CmsPageController extends Controller
{
    protected array $allowedSlugs = ['faq', 'privacy', 'terms', 'cookies'];

    /**
     * Display a published CMS page by slug (Public).
     *
     * @param string $slug
     * @return JsonResponse
     */
    public function show(string $slug): JsonResponse
    {
        if (!in_array($slug, $this->allowedSlugs, true)) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $page = Page::where('slug', $slug)
            ->where('is_published', true)
            ->first();

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $sections = $page->sections()
            ->where('is_published', true)
            ->get();

        if ($slug === 'faq' || $page->type === 'faq') {
            $formattedItems = $sections->map(function ($section, $index) {
                return [
                    'id' => $section->id,
                    'question' => $section->question,
                    'answer' => $section->answer,
                    'order' => $section->sort_order ?: ($index + 1),
                ];
            });

            return response()->json([
                'status' => 'success',
                'data' => [
                    'slug' => $page->slug,
                    'title' => $page->title,
                    'subtitle' => $page->subtitle,
                    'updated_at' => $page->updated_at ? $page->updated_at->toIso8601String() : null,
                    'items' => $formattedItems,
                ],
            ]);
        }

        $formattedSections = $sections->map(function ($section, $index) {
            return [
                'id' => $section->id,
                'heading' => $section->heading,
                'body' => $section->body,
                'order' => $section->sort_order ?: ($index + 1),
            ];
        });

        return response()->json([
            'status' => 'success',
            'data' => [
                'slug' => $page->slug,
                'title' => $page->title,
                'subtitle' => $page->subtitle,
                'updated_at' => $page->updated_at ? $page->updated_at->toIso8601String() : null,
                'sections' => $formattedSections,
            ],
        ]);
    }

    // ==========================================
    // ADMIN CMS MANAGEMENT ENDPOINTS
    // ==========================================

    /**
     * List all CMS pages (Admin only).
     *
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        $pages = Page::withCount('sections')->latest()->get();

        return response()->json([
            'status' => 'success',
            'data' => $pages,
        ]);
    }

    /**
     * Show full page details including all draft/published sections (Admin only).
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function adminShow($id): JsonResponse
    {
        $page = Page::with('sections')->find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'data' => $page,
        ]);
    }

    /**
     * Create a new CMS page (Admin only).
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'slug' => ['required', 'string', 'in:faq,privacy,terms,cookies', 'unique:pages,slug'],
            'title' => ['required', 'string', 'max:255'],
            'subtitle' => ['nullable', 'string', 'max:255'],
            'type' => ['required', 'string', 'in:faq,legal'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $isPublished = $request->boolean('is_published');
        $page = Page::create([
            'slug' => strtolower($request->input('slug')),
            'title' => $request->input('title'),
            'subtitle' => $request->input('subtitle'),
            'type' => $request->input('type'),
            'is_published' => $isPublished,
            'published_at' => $isPublished ? now() : null,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Page created successfully',
            'data' => $page,
        ], 201);
    }

    /**
     * Update an existing CMS page (Admin only).
     *
     * @param Request $request
     * @param int|string $id
     * @return JsonResponse
     */
    public function update(Request $request, $id): JsonResponse
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'title' => ['sometimes', 'required', 'string', 'max:255'],
            'subtitle' => ['nullable', 'string', 'max:255'],
            'type' => ['sometimes', 'required', 'string', 'in:faq,legal'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('title')) {
            $page->title = $request->input('title');
        }
        if ($request->has('subtitle')) {
            $page->subtitle = $request->input('subtitle');
        }
        if ($request->has('type')) {
            $page->type = $request->input('type');
        }
        if ($request->has('is_published')) {
            $page->is_published = $request->boolean('is_published');
            if ($page->is_published && !$page->published_at) {
                $page->published_at = now();
            }
        }

        $page->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Page updated successfully',
            'data' => $page,
        ]);
    }

    /**
     * Delete a CMS page (Admin only).
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function destroy($id): JsonResponse
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $page->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Page deleted successfully',
        ]);
    }

    /**
     * Publish a CMS page (Admin only).
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function publish($id): JsonResponse
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $page->is_published = true;
        $page->published_at = now();
        $page->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Page published successfully',
            'data' => $page,
        ]);
    }

    /**
     * Unpublish a CMS page (Admin only).
     *
     * @param int|string $id
     * @return JsonResponse
     */
    public function unpublish($id): JsonResponse
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $page->is_published = false;
        $page->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Page unpublished successfully',
            'data' => $page,
        ]);
    }

    /**
     * Add a section or FAQ item to a page (Admin only).
     *
     * @param Request $request
     * @param int|string $id
     * @return JsonResponse
     */
    public function storeSection(Request $request, $id): JsonResponse
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'heading' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'question' => ['nullable', 'string'],
            'answer' => ['nullable', 'string'],
            'order' => ['nullable', 'integer'],
            'sort_order' => ['nullable', 'integer'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $order = $request->input('order') ?? $request->input('sort_order') ?? ($page->sections()->max('sort_order') + 1);

        $section = PageSection::create([
            'page_id' => $page->id,
            'heading' => $request->input('heading'),
            'body' => $request->input('body'),
            'question' => $request->input('question'),
            'answer' => $request->input('answer'),
            'sort_order' => (int) $order,
            'is_published' => $request->boolean('is_published', true),
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Section created successfully',
            'data' => $section,
        ], 201);
    }

    /**
     * Update an existing section or FAQ item (Admin only).
     *
     * @param Request $request
     * @param int|string $pageId
     * @param int|string $sectionId
     * @return JsonResponse
     */
    public function updateSection(Request $request, $pageId, $sectionId): JsonResponse
    {
        $section = PageSection::where('page_id', $pageId)->where('id', $sectionId)->first();

        if (!$section) {
            return response()->json([
                'status' => 'error',
                'message' => 'Section not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'heading' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'question' => ['nullable', 'string'],
            'answer' => ['nullable', 'string'],
            'order' => ['nullable', 'integer'],
            'sort_order' => ['nullable', 'integer'],
            'is_published' => ['nullable', 'boolean'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        if ($request->has('heading')) {
            $section->heading = $request->input('heading');
        }
        if ($request->has('body')) {
            $section->body = $request->input('body');
        }
        if ($request->has('question')) {
            $section->question = $request->input('question');
        }
        if ($request->has('answer')) {
            $section->answer = $request->input('answer');
        }
        if ($request->has('order') || $request->has('sort_order')) {
            $section->sort_order = (int) ($request->input('order') ?? $request->input('sort_order'));
        }
        if ($request->has('is_published')) {
            $section->is_published = $request->boolean('is_published');
        }

        $section->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Section updated successfully',
            'data' => $section,
        ]);
    }

    /**
     * Delete a section or FAQ item (Admin only).
     *
     * @param int|string $pageId
     * @param int|string $sectionId
     * @return JsonResponse
     */
    public function destroySection($pageId, $sectionId): JsonResponse
    {
        $section = PageSection::where('page_id', $pageId)->where('id', $sectionId)->first();

        if (!$section) {
            return response()->json([
                'status' => 'error',
                'message' => 'Section not found',
            ], 404);
        }

        $section->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Section deleted successfully',
        ]);
    }

    /**
     * Batch reorder sections or FAQ items for a page (Admin only).
     *
     * @param Request $request
     * @param int|string $id
     * @return JsonResponse
     */
    public function reorderSections(Request $request, $id): JsonResponse
    {
        $page = Page::find($id);

        if (!$page) {
            return response()->json([
                'status' => 'error',
                'message' => 'Page not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'items' => ['required', 'array'],
            'items.*.id' => ['required', 'integer'],
            'items.*.order' => ['nullable', 'integer'],
            'items.*.sort_order' => ['nullable', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        foreach ($request->input('items') as $item) {
            $sectionId = $item['id'];
            $newOrder = $item['order'] ?? $item['sort_order'] ?? 0;

            PageSection::where('page_id', $page->id)
                ->where('id', $sectionId)
                ->update(['sort_order' => (int) $newOrder]);
        }

        $updatedSections = $page->sections()->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Sections reordered successfully',
            'data' => $updatedSections,
        ]);
    }
}
