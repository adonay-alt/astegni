<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Resource extends Model
{
    use HasFactory;

    protected $fillable = [
        'grade_id',
        'subject_id',
        'chapter_id',
        'title',
        'type',
        'url',
        'description',
    ];

    protected $appends = [
        'file_url',
    ];
protected $hidden = ['created_at', 'updated_at'];
    /**
     * Get the grade that owns the resource.
     */
    public function grade(): BelongsTo
    {
        return $this->belongsTo(Grade::class);
    }

    /**
     * Get the subject that owns the resource.
     */
    public function subject(): BelongsTo
    {
        return $this->belongsTo(Subject::class);
    }

    /**
     * Get the chapter that owns the resource.
     */
    public function chapter(): BelongsTo
    {
        return $this->belongsTo(Chapter::class);
    }

    /**
     * Accessor to return full public URL for the resource file.
     *
     * @param string|null $value
     * @return string
     */
    public function getUrlAttribute(?string $value): string
    {
        if (!$value) {
            return '';
        }
        if (str_starts_with($value, 'http://') || str_starts_with($value, 'https://')) {
            return $value;
        }
        return \Illuminate\Support\Facades\Storage::disk('public')->url($value);
    }

    /**
     * Accessor to expose file_url in JSON response matching textbook interface.
     *
     * @return string
     */
    public function getFileUrlAttribute(): string
    {
        return $this->url;
    }
}
