<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'grade',
        'is_admin',
        'otp',
        'otp_expires_at',
        'email_verified_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'otp',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'grade' => 'integer',
            'is_admin' => 'boolean',
            'otp_expires_at' => 'datetime',
        ];
    }

    /**
     * The "booted" method of the model.
     * Register model event listeners for cascading profile deletion to trigger file cleanup.
     */
    protected static function booted(): void
    {
        static::deleting(function (User $user) {
            $user->tutorProfile?->delete();
            $user->studentProfile?->delete();
        });
    }

    /**
     * Get the user's full name.
     */
    public function getNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    /**
     * Get the grade model associated with the user.
     */
    public function gradeRelation(): BelongsTo
    {
        return $this->belongsTo(Grade::class, 'grade', 'id');
    }

    /**
     * Get the grade model associated with the user.
     */
    public function grade(): BelongsTo
    {
        return $this->belongsTo(Grade::class, 'grade', 'id');
    }

    /**
     * Get the student profile associated with the user.
     */
    public function studentProfile(): HasOne
    {
        return $this->hasOne(StudentProfile::class);
    }

    /**
     * Get the tutor profile associated with the user.
     */
    public function tutorProfile(): HasOne
    {
        return $this->hasOne(TutorProfile::class);
    }

    /**
     * Get the quiz results associated with the user.
     */
    public function quizResults(): HasMany
    {
        return $this->hasMany(QuizResult::class);
    }

    /**
     * Get the national exam results associated with the user.
     */
    public function nationalExamResults(): HasMany
    {
        return $this->hasMany(NationalExamResult::class);
    }

    /**
     * Get the chapter progress records associated with the user.
     */
    public function chapterProgress(): HasMany
    {
        return $this->hasMany(ChapterProgress::class);
    }

    /**
     * Get the bookmarks associated with the user.
     */
    public function bookmarks(): HasMany
    {
        return $this->hasMany(Bookmark::class);
    }

    /**
     * Get the in-app notifications associated with the user.
     */
    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class)->latest();
    }

    /**
     * Get the user's profile photo URL (checking student profile photo first, then tutor profile image).
     */
    public function getProfilePhotoUrlAttribute(): ?string
    {
        if ($this->relationLoaded('studentProfile') && $this->studentProfile && $this->studentProfile->photo_url) {
            return $this->studentProfile->photo_url;
        }

        if ($this->studentProfile && $this->studentProfile->photo_url) {
            return $this->studentProfile->photo_url;
        }

        if ($this->relationLoaded('tutorProfile') && $this->tutorProfile && $this->tutorProfile->image_url) {
            return $this->tutorProfile->image_url;
        }

        if ($this->tutorProfile && $this->tutorProfile->image_url) {
            return $this->tutorProfile->image_url;
        }

        return null;
    }
}


