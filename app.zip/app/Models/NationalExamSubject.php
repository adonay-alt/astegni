<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class NationalExamSubject extends Model
{
    use HasFactory;

    protected $table = 'national_exam_subjects';

    protected $fillable = [
        'national_exam_id',
        'national_exam_year_id',
        'grade_id',
        'stream_id',
        'name',
        'description',
    ];

    /**
     * Get the national exam that owns the subject.
     */
    public function nationalExam(): BelongsTo
    {
        return $this->belongsTo(NationalExam::class);
    }

    /**
     * Get the national exam year that owns the subject.
     */
    public function nationalExamYear(): BelongsTo
    {
        return $this->belongsTo(NationalExamYear::class);
    }

    /**
     * Get the grade that owns the subject.
     */
    public function grade(): BelongsTo
    {
        return $this->belongsTo(Grade::class);
    }

    /**
     * Get the stream that owns the subject.
     */
    public function stream(): BelongsTo
    {
        return $this->belongsTo(Stream::class);
    }

    /**
     * Get the exam questions for this subject.
     */
    public function questions(): HasMany
    {
        return $this->hasMany(NationalExamQuestion::class);
    }

    /**
     * Get the results for this exam subject.
     */
    public function results(): HasMany
    {
        return $this->hasMany(NationalExamResult::class);
    }
}
