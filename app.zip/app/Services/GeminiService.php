<?php

namespace App\Services;

use App\Models\Chapter;
use Illuminate\Support\Facades\Http;
use Exception;

class GeminiService
{
    protected string $apiKey;
    protected string $model;

    public function __construct()
    {
        $this->apiKey = (string) (config('services.gemini.api_key') ?: env('GEMINI_API_KEY', ''));
        $this->model = (string) (config('services.gemini.model') ?: env('GEMINI_MODEL', 'gemini-1.5-flash'));
    }

    /**
     * Generate student study notes from a PDF file using Google Gemini API.
     *
     * @param string $pdfPath Absolute path to the PDF on disk
     * @param string $chapterTitle Title of the chapter
     * @param string|null $gradeLevel Optional grade context (e.g., Grade 11)
     * @return string Markdown formatted notes
     * @throws Exception
     */
    public function generateNotesFromPdf(string $pdfPath, string $chapterTitle, ?string $gradeLevel = null): string
    {
        if (empty($this->apiKey)) {
            throw new Exception("Gemini API key is not configured. Please set GEMINI_API_KEY in your .env file.");
        }

        if (!file_exists($pdfPath)) {
            throw new Exception("PDF file not found at path: {$pdfPath}");
        }

        $fileSizeBytes = filesize($pdfPath);
        $filePart = null;
        $uploadedFileName = null;

        try {
            if ($fileSizeBytes <= 15 * 1024 * 1024) {
                // Inline Base64 approach for <= 15MB files
                $pdfContent = file_get_contents($pdfPath);
                if ($pdfContent === false) {
                    throw new Exception("Failed to read PDF content at: {$pdfPath}");
                }
                $pdfBase64 = base64_encode($pdfContent);
                $filePart = [
                    'inline_data' => [
                        'mime_type' => 'application/pdf',
                        'data' => $pdfBase64,
                    ]
                ];
            } else {
                // Upload via Google Gemini Files API for > 15MB files
                $stream = fopen($pdfPath, 'r');
                if ($stream === false) {
                    throw new Exception("Failed to open file stream for upload at: {$pdfPath}");
                }

                $uploadResponse = Http::timeout(120)
                    ->retry(3, 4000, function ($exception, $request) {
                        return $exception instanceof \Illuminate\Http\Client\ConnectionException
                            || ($exception instanceof \Illuminate\Http\Client\RequestException && in_array($exception->response->status(), [429, 500, 502, 503, 504]));
                    }, throw: false)
                    ->withHeaders([
                        'X-Goog-Upload-Command' => 'upload, finalize',
                        'X-Goog-Upload-Header-Content-Length' => (string) $fileSizeBytes,
                        'X-Goog-Upload-Header-Content-Type' => 'application/pdf',
                        'Content-Type' => 'application/pdf',
                    ])
                    ->withBody($stream, 'application/pdf')
                    ->post("https://generativelanguage.googleapis.com/upload/v1beta/files?key={$this->apiKey}");

                if (is_resource($stream)) {
                    fclose($stream);
                }

                if ($uploadResponse->failed()) {
                    throw new Exception("Gemini File Upload Failed (HTTP {$uploadResponse->status()}): " . $uploadResponse->body());
                }

                $uploadJson = $uploadResponse->json();
                $fileUri = $uploadJson['file']['uri'] ?? null;
                $uploadedFileName = $uploadJson['file']['name'] ?? null; // e.g. files/abc123

                if (empty($fileUri)) {
                    throw new Exception("Gemini File Upload returned invalid URI response.");
                }

                $filePart = [
                    'file_data' => [
                        'mime_type' => 'application/pdf',
                        'file_uri' => $fileUri,
                    ]
                ];
            }

            $gradeInfo = $gradeLevel ? " for {$gradeLevel}" : "";

            // Tailored prompt for Ethiopian High School Curriculum (Grade 9-12)
            $prompt = <<<TEXT
You are an expert high school educator specializing in the Ethiopian National Curriculum (Ministry of Education standards).
Analyze the attached textbook chapter PDF titled "{$chapterTitle}"{$gradeInfo}.

Generate comprehensive, well-structured, clear revision notes for Grade 9-12 high school students covering:
1. **Chapter Overview & Learning Objectives**: Brief summary of core topics covered and key student competencies expected in national/regional exams.
2. **Key Concepts & Essential Definitions**: Clear, concise explanations of terms and terminology.
3. **Core Lessons & Detailed Explanations**: In-depth bullet points, essential formulas, principles, or rules explained clearly.
4. **Worked Examples & Practical Applications**: Step-by-step solutions for sample problems, real-world examples, or diagram walkthroughs.
5. **Exam Revision Summary**: Quick key takeaways and summary points for national exam prep.
6. **5 Practice / Self-Test Questions**: Review questions with short, accurate answer keys at the bottom.

Formatting Rules:
- Format the output strictly in clean Markdown (H2, H3, bullet points, bold text, LaTeX math syntax if relevant).
- Do NOT enclose the overall output in ```markdown ``` triple backtick code blocks.
TEXT;

            $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key={$this->apiKey}";

            $contents = [
                [
                    'role' => 'user',
                    'parts' => [
                        ['text' => $prompt],
                        $filePart
                    ]
                ]
            ];

            $fullText = '';
            $continuationLoops = 0;
            $maxContinuations = 2;

            while (true) {
                $response = Http::timeout(120)
                    ->retry(3, 4000, function ($exception, $request) {
                        // Auto-retry if connection error or transient status code (429, 500, 502, 503, 504)
                        return $exception instanceof \Illuminate\Http\Client\ConnectionException
                            || ($exception instanceof \Illuminate\Http\Client\RequestException && in_array($exception->response->status(), [429, 500, 502, 503, 504]));
                    }, throw: false)
                    ->post($endpoint, [
                        'contents' => $contents,
                        'generationConfig' => [
                            'temperature' => 0.4,
                            'maxOutputTokens' => 8192,
                        ]
                    ]);

                if ($response->failed()) {
                    throw new Exception("Gemini API Request Failed (HTTP {$response->status()}): " . $response->body());
                }

                $result = $response->json();
                $candidate = $result['candidates'][0] ?? null;

                if (!$candidate) {
                    throw new Exception("Gemini API returned no candidates.");
                }

                // Concatenate all text parts (skip internal thought parts)
                $segmentText = '';
                $parts = $candidate['content']['parts'] ?? [];
                foreach ($parts as $part) {
                    if (!empty($part['thought'])) {
                        continue;
                    }
                    if (!empty($part['text'])) {
                        $segmentText .= $part['text'];
                    }
                }

                if (empty(trim($segmentText)) && empty($fullText)) {
                    throw new Exception("Gemini returned empty text response.");
                }

                $fullText .= $segmentText;
                $finishReason = $candidate['finishReason'] ?? 'STOP';

                if ($finishReason === 'MAX_TOKENS' && $continuationLoops < $maxContinuations) {
                    $continuationLoops++;

                    // Append model response turn
                    $contents[] = [
                        'role' => 'model',
                        'parts' => [
                            ['text' => $segmentText]
                        ]
                    ];

                    // Append follow-up user turn requesting continuation
                    $contents[] = [
                        'role' => 'user',
                        'parts' => [
                            ['text' => 'Continue writing the remaining sections of the study notes exactly where you left off without repeating earlier content.']
                        ]
                    ];
                } else {
                    break;
                }
            }

            // Clean up markdown block wrapping if present
            $cleanedText = preg_replace('/^```(?:markdown)?\s*\n?/i', '', trim($fullText));
            $cleanedText = preg_replace('/\n?```$/', '', trim($cleanedText));

            return trim($cleanedText);

        } finally {
            // Delete uploaded file if we uploaded to Files API
            if (!empty($uploadedFileName)) {
                try {
                    Http::timeout(30)->delete("https://generativelanguage.googleapis.com/v1beta/{$uploadedFileName}?key={$this->apiKey}");
                } catch (\Throwable $e) {
                    // Ignore deletion errors to prevent masking primary outcome
                }
            }
        }
    }

    /**
     * Generate multiple-choice quiz questions from chapter study notes using Google Gemini API.
     *
     * @param string $notesText Raw markdown or text notes
     * @param string $chapterTitle Title of the chapter
     * @param int $questionCount Number of questions to generate (default 10)
     * @return array Array of question items
     * @throws Exception
     */
    public function generateQuizFromNotes(string $notesText, string $chapterTitle, int $questionCount = 10): array
    {
        if (empty($this->apiKey)) {
            throw new Exception("Gemini API key is not configured. Please set GEMINI_API_KEY in your .env file.");
        }

        if (empty(trim($notesText))) {
            throw new Exception("Study notes text is empty for chapter: {$chapterTitle}");
        }

        $prompt = <<<TEXT
You are an expert examiner for the Ethiopian High School curriculum (Grades 9-12 standards).
Analyze the provided study notes for the chapter "{$chapterTitle}" and generate exactly {$questionCount} multiple-choice questions.

The questions must cover a balanced mix of conceptual understanding, key definitions, calculations, and analytical problem-solving suitable for Ethiopian Grade 9-12 national exam standards.

Output MUST be a JSON array of objects strictly matching this structure:
[
  {
    "question": "Clear question text goes here",
    "options": {
      "A": "Option A text",
      "B": "Option B text",
      "C": "Option C text",
      "D": "Option D text"
    },
    "correct_answer": "A",
    "explanation": "Brief explanation why this answer is correct"
  }
]

Rules:
1. Generate exactly {$questionCount} questions.
2. Each question MUST have options A, B, C, and D.
3. "correct_answer" MUST be exactly one uppercase letter: "A", "B", "C", or "D".
4. Provide a helpful explanation for each question.
5. Return strictly valid JSON array without any markdown code block wrappers.

Chapter Notes:
{$notesText}
TEXT;

        $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key={$this->apiKey}";

        $response = Http::timeout(120)
            ->retry(3, 4000, function ($exception, $request) {
                // Auto-retry if connection error or transient status code (429, 500, 502, 503, 504)
                return $exception instanceof \Illuminate\Http\Client\ConnectionException
                    || ($exception instanceof \Illuminate\Http\Client\RequestException && in_array($exception->response->status(), [429, 500, 502, 503, 504]));
            }, throw: false)
            ->post($endpoint, [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.3,
                'maxOutputTokens' => 4000,
                'response_mime_type' => 'application/json',
            ]
        ]);

        if ($response->failed()) {
            throw new Exception("Gemini API Request Failed (HTTP {$response->status()}): " . $response->body());
        }

        $result = $response->json();

        // Concatenate all text parts (skip internal thought parts)
        $fullText = '';
        $parts = $result['candidates'][0]['content']['parts'] ?? [];
        foreach ($parts as $part) {
            if (!empty($part['thought'])) {
                continue;
            }
            if (!empty($part['text'])) {
                $fullText .= $part['text'];
            }
        }

        if (empty(trim($fullText))) {
            throw new Exception("Gemini returned empty text response.");
        }

        $generatedText = $fullText;

        // Clean up markdown block wrapping if present
        $cleanedText = preg_replace('/^```(?:json)?\s*\n?/i', '', trim($generatedText));
        $cleanedText = preg_replace('/\n?```$/', '', trim($cleanedText));

        $questionsArray = json_decode($cleanedText, true);

        if (!is_array($questionsArray)) {
            throw new Exception("Failed to parse Gemini JSON output for quiz generation: " . json_last_error_msg());
        }

        return $questionsArray;
    }

    /**
     * Generate multiple-choice quiz questions from text study notes using Google Gemini API.
     *
     * @param string $notesText Raw markdown or text notes
     * @param string $chapterTitle Title of the chapter
     * @return array Array of question items
     * @throws Exception
     */
    public function generateQuizFromText(string $notesText, string $chapterTitle): array
    {
        return $this->generateQuizFromNotes($notesText, $chapterTitle, 10);
    }

    /**
     * Generate multiple-choice quiz questions directly from a textbook PDF using Google Gemini API.
     *
     * @param string $pdfPath Absolute path to the chapter PDF on disk
     * @param string $chapterTitle Title of the chapter
     * @return array Array of question items
     * @throws Exception
     */
    public function generateQuizFromPdf(string $pdfPath, string $chapterTitle): array
    {
        if (empty($this->apiKey)) {
            throw new Exception("Gemini API key is not configured. Please set GEMINI_API_KEY in your .env file.");
        }

        if (!file_exists($pdfPath)) {
            throw new Exception("PDF file not found at path: {$pdfPath}");
        }

        $fileSizeBytes = filesize($pdfPath);
        $filePart = null;
        $uploadedFileName = null;

        try {
            if ($fileSizeBytes <= 15 * 1024 * 1024) {
                // Inline Base64 approach for <= 15MB files
                $pdfContent = file_get_contents($pdfPath);
                if ($pdfContent === false) {
                    throw new Exception("Failed to read PDF content at: {$pdfPath}");
                }
                $pdfBase64 = base64_encode($pdfContent);
                $filePart = [
                    'inline_data' => [
                        'mime_type' => 'application/pdf',
                        'data' => $pdfBase64,
                    ]
                ];
            } else {
                // Upload via Google Gemini Files API for > 15MB files
                $stream = fopen($pdfPath, 'r');
                if ($stream === false) {
                    throw new Exception("Failed to open file stream for upload at: {$pdfPath}");
                }

                $uploadResponse = Http::timeout(120)
                    ->retry(3, 4000, function ($exception, $request) {
                        return $exception instanceof \Illuminate\Http\Client\ConnectionException
                            || ($exception instanceof \Illuminate\Http\Client\RequestException && in_array($exception->response->status(), [429, 500, 502, 503, 504]));
                    }, throw: false)
                    ->withHeaders([
                        'X-Goog-Upload-Command' => 'upload, finalize',
                        'X-Goog-Upload-Header-Content-Length' => (string) $fileSizeBytes,
                        'X-Goog-Upload-Header-Content-Type' => 'application/pdf',
                        'Content-Type' => 'application/pdf',
                    ])
                    ->withBody($stream, 'application/pdf')
                    ->post("https://generativelanguage.googleapis.com/upload/v1beta/files?key={$this->apiKey}");

                if (is_resource($stream)) {
                    fclose($stream);
                }

                if ($uploadResponse->failed()) {
                    throw new Exception("Gemini File Upload Failed (HTTP {$uploadResponse->status()}): " . $uploadResponse->body());
                }

                $uploadJson = $uploadResponse->json();
                $fileUri = $uploadJson['file']['uri'] ?? null;
                $uploadedFileName = $uploadJson['file']['name'] ?? null;

                if (empty($fileUri)) {
                    throw new Exception("Gemini File Upload returned invalid URI response.");
                }

                $filePart = [
                    'file_data' => [
                        'mime_type' => 'application/pdf',
                        'file_uri' => $fileUri,
                    ]
                ];
            }

            $prompt = <<<TEXT
You are an expert examiner for the Ethiopian High School curriculum (Grades 9-12 standards).
Analyze the attached textbook chapter PDF titled "{$chapterTitle}" and generate exactly 10 multiple-choice questions.

The questions must extract core concepts, essential definitions, calculations, and analytical problem-solving from the chapter suitable for Ethiopian Grade 9-12 national exam standards.

Output MUST be a JSON array of objects strictly matching this structure:
[
  {
    "question": "Clear question text goes here",
    "options": {
      "A": "Option A text",
      "B": "Option B text",
      "C": "Option C text",
      "D": "Option D text"
    },
    "correct_answer": "A",
    "explanation": "Detailed explanation of why A is correct..."
  }
]

Rules:
1. Generate exactly 10 questions.
2. Each question MUST have options A, B, C, and D.
3. "correct_answer" MUST be exactly one uppercase letter: "A", "B", "C", or "D".
4. Provide a helpful, detailed explanation for each question.
5. Return strictly valid JSON array without any markdown code block wrappers.
TEXT;

            $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key={$this->apiKey}";

            $response = Http::timeout(120)
                ->retry(3, 4000, function ($exception, $request) {
                    // Auto-retry if connection error or transient status code (429, 500, 502, 503, 504)
                    return $exception instanceof \Illuminate\Http\Client\ConnectionException
                        || ($exception instanceof \Illuminate\Http\Client\RequestException && in_array($exception->response->status(), [429, 500, 502, 503, 504]));
                }, throw: false)
                ->post($endpoint, [
                    'contents' => [
                        [
                            'parts' => [
                                ['text' => $prompt],
                                $filePart
                            ]
                        ]
                    ],
                    'generationConfig' => [
                        'temperature' => 0.3,
                        'maxOutputTokens' => 4000,
                        'response_mime_type' => 'application/json',
                    ]
                ]);

            if ($response->failed()) {
                throw new Exception("Gemini API Request Failed (HTTP {$response->status()}): " . $response->body());
            }

            $result = $response->json();

            // Concatenate all text parts (skip internal thought parts)
            $fullText = '';
            $parts = $result['candidates'][0]['content']['parts'] ?? [];
            foreach ($parts as $part) {
                if (!empty($part['thought'])) {
                    continue;
                }
                if (!empty($part['text'])) {
                    $fullText .= $part['text'];
                }
            }

            if (empty(trim($fullText))) {
                throw new Exception("Gemini returned empty text response.");
            }

            $generatedText = $fullText;

            // Clean up markdown block wrapping if present
            $cleanedText = preg_replace('/^```(?:json)?\s*\n?/i', '', trim($generatedText));
            $cleanedText = preg_replace('/\n?```$/', '', trim($cleanedText));

            $questionsArray = json_decode($cleanedText, true);

            if (!is_array($questionsArray)) {
                throw new Exception("Failed to parse Gemini JSON output for PDF quiz generation: " . json_last_error_msg());
            }

            return $questionsArray;

        } finally {
            if (!empty($uploadedFileName)) {
                try {
                    Http::timeout(30)->delete("https://generativelanguage.googleapis.com/v1beta/{$uploadedFileName}?key={$this->apiKey}");
                } catch (\Throwable $e) {
                    // Ignore deletion errors to prevent masking primary outcome
                }
            }
        }
    }

    /**
     * Chat with an encouraging, expert Ethiopian High School AI tutor for a specific chapter.
     *
     * @param Chapter $chapter
     * @param string $userMessage
     * @param array $history
     * @return string
     * @throws Exception
     */
    public function chatWithChapter(Chapter $chapter, string $userMessage, array $history = []): string
    {
        if (empty($this->apiKey)) {
            throw new Exception("Gemini API key is not configured. Please set GEMINI_API_KEY in your .env file.");
        }

        $gradeName = $chapter->grade?->name ?? 'High School';
        $subjectName = $chapter->subject?->title ?? ($chapter->subject?->name ?? 'General Studies');
        $notesContent = !empty(trim((string)$chapter->ai_generated_notes)) 
            ? $chapter->ai_generated_notes 
            : ($chapter->description ?: 'No detailed revision notes currently available for this chapter.');

        $systemInstructionText = <<<INSTRUCTION
You are an encouraging, expert Ethiopian High School AI tutor on the learning platform Asteghi for {$gradeName} {$subjectName}.
Your mission is to help high school students master this chapter: '{$chapter->title}'.
Base your answers primarily on this chapter's study notes:
{$notesContent}

Guidelines:
- Be clear, supportive, and concise (ideal for high school level).
- If explaining formulas, use standard LaTeX ($...$ or $$...$$).
- Provide real-world Ethiopian context or everyday analogies where helpful.
- If the student asks something completely off-topic from high school studies, politely guide them back to the chapter.
INSTRUCTION;

        $contents = [];

        // Build conversation history in Gemini format
        foreach ($history as $item) {
            if (!is_array($item)) {
                continue;
            }

            $rawRole = strtolower(trim((string)($item['role'] ?? 'user')));
            $role = match ($rawRole) {
                'model', 'assistant', 'bot' => 'model',
                default => 'user',
            };

            $text = $item['text'] ?? ($item['content'] ?? ($item['message'] ?? ''));
            if (is_array($text)) {
                $text = $text[0]['text'] ?? json_encode($text);
            }

            $text = trim((string)$text);
            if ($text === '') {
                continue;
            }

            $contents[] = [
                'role' => $role,
                'parts' => [
                    ['text' => $text]
                ]
            ];
        }

        // Append current user message
        $contents[] = [
            'role' => 'user',
            'parts' => [
                ['text' => trim($userMessage)]
            ]
        ];

        $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key={$this->apiKey}";

        $payload = [
            'system_instruction' => [
                'parts' => [
                    ['text' => $systemInstructionText]
                ]
            ],
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => 0.5,
                'maxOutputTokens' => 2048,
            ]
        ];

        $response = Http::timeout(120)
            ->retry(3, 4000, function ($exception, $request) {
                // Auto-retry if connection error or transient status code (429, 500, 502, 503, 504)
                return $exception instanceof \Illuminate\Http\Client\ConnectionException
                    || ($exception instanceof \Illuminate\Http\Client\RequestException && in_array($exception->response->status(), [429, 500, 502, 503, 504]));
            }, throw: false)
            ->post($endpoint, $payload);

        if ($response->failed()) {
            throw new Exception("Gemini Chat Request Failed (HTTP {$response->status()}): " . $response->body());
        }

        $result = $response->json();

        // Concatenate all text parts (skip internal thought parts)
        $fullText = '';
        $parts = $result['candidates'][0]['content']['parts'] ?? [];
        foreach ($parts as $part) {
            if (!empty($part['thought'])) {
                continue;
            }
            if (!empty($part['text'])) {
                $fullText .= $part['text'];
            }
        }

        if (empty(trim($fullText))) {
            throw new Exception("Gemini returned an empty response for tutor chat.");
        }

        $generatedText = $fullText;

        return trim($generatedText);
    }
}
